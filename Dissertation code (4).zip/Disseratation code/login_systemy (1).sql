-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2019 at 12:23 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_systemy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_y`
--

CREATE TABLE `admin_y` (
  `id` int(11) NOT NULL,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lname` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_level` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=pending,1=confirmed	'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_y`
--

INSERT INTO `admin_y` (`id`, `name`, `lname`, `username`, `address`, `country`, `number`, `password`, `access_level`, `status`) VALUES
(2, 'Admin', 'Personnel', 'admin', '1, Culwell Street\r\nLiberty Heights. B23 room 4', 'United Kingdom', '84389049389', '$2y$10$XZqqRYVpWr7qPlozYMfJAui246hKVwbEi/rQe8zkpdISIq9TX9BCa', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `failed_login`
--

CREATE TABLE `failed_login` (
  `id` int(11) NOT NULL,
  `IP` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `failed_login`
--

INSERT INTO `failed_login` (`id`, `IP`, `username`, `user_url`, `date`) VALUES
(239, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 05:24:48'),
(240, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 05:25:31'),
(241, '127.0.0.1', 'kmkm', '/secure/login.php', '2019-04-10 05:26:19'),
(242, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 05:28:15'),
(243, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 05:28:55'),
(244, '127.0.0.1', 'kmm', '/SiteY/login.php', '2019-04-10 05:31:24'),
(245, '127.0.0.1', 'hbhb', '/secure/login.php', '2019-04-10 05:32:57'),
(246, '127.0.0.1', 'kmk', '/secure/login.php', '2019-04-10 05:37:37'),
(247, '127.0.0.1', 'mnjn', '/secure/login.php', '2019-04-10 05:37:53'),
(248, '127.0.0.1', 'kmkm', '/secure/login.php', '2019-04-10 05:38:16'),
(249, '127.0.0.1', 'jjnjn', '/secure/login.php', '2019-04-10 05:38:42'),
(250, '127.0.0.1', 'jnjn', '/SiteY/login.php', '2019-04-10 05:39:14'),
(251, '127.0.0.1', 'kkm', '/SiteY/login.php', '2019-04-10 05:39:29'),
(252, '127.0.0.1', 'kjnjnq', '/SiteY/login.php', '2019-04-10 05:39:45'),
(253, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 05:54:30'),
(254, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 05:54:59'),
(255, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 05:55:25'),
(256, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 05:55:54'),
(257, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:02:02'),
(258, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:02:29'),
(259, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:02:51'),
(260, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:03:09'),
(261, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:04:59'),
(262, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:05:16'),
(263, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:05:36'),
(264, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:05:56'),
(265, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:08:36'),
(266, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:09:11'),
(267, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:09:29'),
(268, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:09:50'),
(269, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:11:45'),
(270, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:12:02'),
(271, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:12:17'),
(272, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:19:00'),
(273, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:19:40'),
(274, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:20:09'),
(275, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:20:34'),
(276, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:28:33'),
(277, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:29:45'),
(278, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:30:12'),
(279, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:31:10'),
(280, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:33:06'),
(281, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:34:27'),
(282, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:34:35'),
(283, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:36:39'),
(284, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:37:02'),
(285, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:37:10'),
(286, '127.0.0.1', 'rachel98', '/secure/login.php', '2019-04-10 06:38:17'),
(287, '127.0.0.1', 'rachel98', '/secure/login.php', '2019-04-10 06:38:33'),
(288, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:38:49'),
(289, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:39:01'),
(290, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:39:25'),
(291, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:39:31'),
(292, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:39:50'),
(293, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:40:01'),
(294, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:40:10'),
(295, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:50:00'),
(296, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:50:27'),
(297, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:50:31'),
(298, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:50:35'),
(299, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:50:39'),
(300, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:50:42'),
(301, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:51:32'),
(302, '127.0.0.1', 'rachel98', '/secure/login.php', '2019-04-10 06:51:37'),
(303, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:51:41'),
(304, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 06:52:04'),
(305, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 06:52:13'),
(306, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 06:52:23'),
(307, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 06:52:33'),
(308, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:52:59'),
(309, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:53:06'),
(310, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:53:11'),
(311, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:53:20'),
(312, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:53:25'),
(313, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:56:01'),
(314, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:57:32'),
(315, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:57:40'),
(316, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:57:46'),
(317, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:57:52'),
(318, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:57:58'),
(319, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:58:05'),
(320, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:58:12'),
(321, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:58:18'),
(322, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:59:01'),
(323, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:59:09'),
(324, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:59:15'),
(325, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 06:59:21'),
(326, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:00:40'),
(327, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:00:55'),
(328, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:01:02'),
(329, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:01:11'),
(330, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:02:18'),
(331, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:02:38'),
(332, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:02:45'),
(333, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:02:53'),
(334, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:03:03'),
(335, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:10:47'),
(336, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:10:54'),
(337, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:11:00'),
(338, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 07:11:09'),
(339, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:38:16'),
(340, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:38:23'),
(341, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:55:46'),
(342, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:55:53'),
(343, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:56:01'),
(344, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:57:07'),
(345, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:57:13'),
(346, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:57:20'),
(347, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:58:59'),
(348, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:59:06'),
(349, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 07:59:13'),
(350, '127.0.0.1', '', '/SiteY/login.php', '2019-04-10 08:02:41'),
(351, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:03:31'),
(352, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:03:37'),
(353, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:03:44'),
(354, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:05:19'),
(355, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:05:26'),
(356, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:05:34'),
(357, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:06:30'),
(358, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:06:35'),
(359, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:06:45'),
(360, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:07:20'),
(361, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:07:27'),
(362, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:07:33'),
(363, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:13:33'),
(364, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:13:40'),
(365, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:13:48'),
(366, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:19:30'),
(367, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:19:40'),
(368, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:19:47'),
(369, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:20:15'),
(370, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:20:20'),
(371, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:21:41'),
(372, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 08:21:48'),
(373, '127.0.0.1', 'JJJN', '/SiteY/login.php', '2019-04-10 08:23:20'),
(374, '127.0.0.1', 'JJJN', '/SiteY/login.php', '2019-04-10 08:23:47'),
(375, '127.0.0.1', 'JJJN', '/SiteY/login.php', '2019-04-10 08:23:57'),
(376, '127.0.0.1', 'JJJN', '/SiteY/login.php', '2019-04-10 08:24:16'),
(377, '127.0.0.1', 'kkm', '/secure/login.php', '2019-04-10 08:29:13'),
(378, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 08:29:24'),
(379, '127.0.0.1', 'kkm', '/secure/login.php', '2019-04-10 08:44:24'),
(380, '127.0.0.1', 'jnnj', '/secure/login.php', '2019-04-10 08:44:30'),
(381, '127.0.0.1', 'jnj', '/secure/login.php', '2019-04-10 08:51:22'),
(382, '127.0.0.1', 'pete', '/secure/login.php', '2019-04-10 08:51:29'),
(383, '127.0.0.1', 'km', '/secure/login.php', '2019-04-10 09:00:08'),
(384, '127.0.0.1', 'jnnj', '/secure/login.php', '2019-04-10 15:27:05'),
(385, '127.0.0.1', 'jn', '/secure/login.php', '2019-04-10 15:27:10'),
(386, '127.0.0.1', 'jn', '/secure/login.php', '2019-04-10 15:34:05'),
(387, '127.0.0.1', 'jn', '/secure/login.php', '2019-04-10 15:34:46'),
(388, '127.0.0.1', 'jn', '/secure/login.php', '2019-04-10 15:35:44'),
(389, '127.0.0.1', 'jn', '/secure/login.php', '2019-04-10 15:36:45'),
(390, '127.0.0.1', 'jn', '/secure/login.php', '2019-04-10 15:38:10'),
(391, '127.0.0.1', 'jjknn', '/secure/login.php', '2019-04-10 15:38:16'),
(392, '127.0.0.1', 'jhh', '/SiteY/login.php', '2019-04-10 15:53:35'),
(393, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 15:53:45'),
(394, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 15:55:12'),
(395, '127.0.0.1', 'jnj', '/SiteY/login.php', '2019-04-10 16:00:51'),
(396, '127.0.0.1', 'jnj', '/SiteY/login.php', '2019-04-10 16:01:36'),
(397, '127.0.0.1', 'nk', '/SiteY/login.php', '2019-04-10 16:01:40'),
(398, '127.0.0.1', 'jnjn', '/SiteY/login.php', '2019-04-10 16:02:15'),
(399, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:02:25'),
(400, '127.0.0.1', 'km', '/SiteY/login.php', '2019-04-10 16:03:48'),
(401, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:04:30'),
(402, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:04:45'),
(403, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:05:44'),
(404, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:05:59'),
(405, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:06:45'),
(406, '127.0.0.1', 'jnj', '/SiteY/login.php', '2019-04-10 16:45:22'),
(407, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:45:47'),
(408, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:46:43'),
(409, '127.0.0.1', 'j', '/SiteY/login.php', '2019-04-10 16:46:52'),
(410, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:49:38'),
(411, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 16:49:52'),
(412, '127.0.0.1', 'kmk', '/SiteY/login.php', '2019-04-10 16:50:58'),
(413, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 17:30:47'),
(414, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 17:32:59'),
(415, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 17:34:05'),
(416, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 17:34:41'),
(417, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 17:37:58'),
(418, '127.0.0.1', 'ggh', '/SiteY/login.php', '2019-04-10 17:38:49'),
(419, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 17:39:05'),
(420, '127.0.0.1', 'jbhb', '/SiteY/login.php', '2019-04-10 17:40:01'),
(421, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 18:02:56'),
(422, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 18:04:54'),
(423, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 18:06:51'),
(424, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 18:07:25'),
(425, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:03:35'),
(426, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:04:02'),
(427, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:04:22'),
(428, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:04:38'),
(429, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:04:49'),
(430, '127.0.0.1', 'jnjn', '/SiteY/login.php', '2019-04-10 19:05:01'),
(431, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:05:13'),
(432, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:05:20'),
(433, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:05:39'),
(434, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:07:55'),
(435, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:08:10'),
(436, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:08:53'),
(437, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:09:26'),
(438, '127.0.0.1', 'jj', '/SiteY/login.php', '2019-04-10 19:09:37'),
(439, '127.0.0.1', 'jj', '/SiteY/login.php', '2019-04-10 19:09:41'),
(440, '127.0.0.1', 'jj', '/SiteY/login.php', '2019-04-10 19:10:22'),
(441, '127.0.0.1', 'jj', '/SiteY/login.php', '2019-04-10 19:10:58'),
(442, '127.0.0.1', 'jj', '/SiteY/login.php', '2019-04-10 19:11:28'),
(443, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:13:47'),
(444, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:15:11'),
(445, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:16:32'),
(446, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:16:41'),
(447, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:17:02'),
(448, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:17:12'),
(449, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:18:28'),
(450, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:21:35'),
(451, '127.0.0.1', 'km', '/secure/login.php', '2019-04-10 19:25:52'),
(452, '127.0.0.1', 'jnjn', '/secure/login.php', '2019-04-10 19:26:10'),
(453, '127.0.0.1', 'jnjn', '/secure/login.php', '2019-04-10 19:27:21'),
(454, '127.0.0.1', 'peternnj', '/secure/login.php', '2019-04-10 19:27:52'),
(455, '127.0.0.1', 'jbjjnj', '/secure/login.php', '2019-04-10 19:29:03'),
(456, '127.0.0.1', 'jbjjnj', '/secure/login.php', '2019-04-10 19:30:26'),
(457, '127.0.0.1', 'jnjn', '/secure/login.php', '2019-04-10 19:30:42'),
(458, '127.0.0.1', 'jnjn', '/secure/login.php', '2019-04-10 19:33:03'),
(459, '127.0.0.1', 'pkmd', '/secure/login.php', '2019-04-10 19:33:23'),
(460, '127.0.0.1', 'jnjn', '/SiteY/login.php', '2019-04-10 19:38:11'),
(461, '127.0.0.1', 'jnj', '/SiteY/login.php', '2019-04-10 19:38:18'),
(462, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 19:38:33'),
(463, '127.0.0.1', 'jnjnj', '/SiteY/login.php', '2019-04-10 19:39:41'),
(464, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 20:07:48'),
(465, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 20:09:36'),
(466, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 20:10:57'),
(467, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 20:18:40'),
(468, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 20:19:15'),
(469, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-10 20:22:25'),
(470, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 20:29:48'),
(471, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 20:33:59'),
(472, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 20:35:45'),
(473, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 20:38:37'),
(474, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 20:40:22'),
(475, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-10 20:47:24'),
(476, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:03:56'),
(477, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:05:06'),
(478, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:07:06'),
(479, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:07:22'),
(480, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:07:33'),
(481, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:13:18'),
(482, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:22:23'),
(483, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:22:34'),
(484, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 02:23:10'),
(485, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:23:31'),
(486, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:26:22'),
(487, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:28:14'),
(488, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:34:27'),
(489, '127.0.0.1', 'admin123', '/secure/login.php', '2019-04-11 02:36:57'),
(490, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:37:16'),
(491, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:38:50'),
(492, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:43:02'),
(493, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:50:48'),
(494, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:52:53'),
(495, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-11 02:54:57'),
(496, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 03:57:07'),
(497, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 11:36:10'),
(498, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 12:15:40'),
(499, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:29:22'),
(500, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:31:51'),
(501, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:36:57'),
(502, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:37:23'),
(503, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:44:28'),
(504, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:50:58'),
(505, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:52:02'),
(506, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:53:22'),
(507, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 13:59:09'),
(508, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 14:37:12'),
(509, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 15:24:25'),
(510, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 15:25:47'),
(511, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 15:26:22'),
(512, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 15:30:09'),
(513, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 15:33:18'),
(514, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 15:35:20'),
(515, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 15:43:02'),
(516, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 15:43:43'),
(517, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 15:43:58'),
(518, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 15:45:50'),
(519, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 16:57:52'),
(520, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 17:01:00'),
(521, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 17:03:14'),
(522, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 17:09:15'),
(523, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 17:24:33'),
(524, '127.0.0.1', 'peter00', '/SiteY/login.php', '2019-04-11 17:26:25'),
(525, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 17:28:45'),
(526, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 17:30:47'),
(527, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 17:31:00'),
(528, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 17:31:33'),
(529, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 17:32:08'),
(530, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 17:33:51'),
(531, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 17:34:35'),
(532, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 18:51:18'),
(533, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 18:51:53'),
(534, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 19:19:54'),
(535, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 19:21:57'),
(536, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 21:10:02'),
(537, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 21:10:57'),
(538, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 21:11:37'),
(539, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-11 21:42:52'),
(540, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 00:28:15'),
(541, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 00:54:15'),
(542, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 01:55:04'),
(543, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:00:22'),
(544, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:01:55'),
(545, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:02:16'),
(546, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:03:54'),
(547, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:03:58'),
(548, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:04:05'),
(549, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:05:14'),
(550, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:06:18'),
(551, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:07:20'),
(552, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:07:40'),
(553, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:08:03'),
(554, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:08:35'),
(555, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:09:10'),
(556, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 02:09:40'),
(557, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 02:23:09'),
(558, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 02:23:23'),
(559, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 03:16:59'),
(560, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:24:09'),
(561, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:29:53'),
(562, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:30:04'),
(563, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:32:15'),
(564, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:32:50'),
(565, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:33:45'),
(566, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:34:29'),
(567, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:36:11'),
(568, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:36:32'),
(569, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:37:18'),
(570, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:41:57'),
(571, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:43:05'),
(572, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:46:34'),
(573, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:53:40'),
(574, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:54:03'),
(575, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 03:54:38'),
(576, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 03:59:26'),
(577, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 04:03:02'),
(578, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 04:05:25'),
(579, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 04:08:30'),
(580, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 04:11:58'),
(581, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 04:41:40'),
(582, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 05:12:50'),
(583, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 05:22:37'),
(584, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 05:50:51'),
(585, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 06:28:37'),
(586, '127.0.0.1', 'admin', '/secure/login.php', '2019-04-12 06:56:22'),
(587, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 16:54:33'),
(588, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 17:35:52'),
(589, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 18:05:08'),
(590, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 18:23:23'),
(591, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 18:31:52'),
(592, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 18:32:15'),
(593, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 18:33:32'),
(594, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 18:35:40'),
(595, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 18:36:19'),
(596, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 18:36:28'),
(597, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 19:20:11'),
(598, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 20:17:12'),
(599, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 20:22:04'),
(600, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 20:57:16'),
(601, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 20:59:23'),
(602, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 21:03:49'),
(603, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 21:08:10'),
(604, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 21:08:55'),
(605, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 21:10:46'),
(606, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 21:12:50'),
(607, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 21:51:12'),
(608, '127.0.0.1', 'peter00', '/secure/login.php', '2019-04-12 21:54:14'),
(609, '127.0.0.1', 'peter00', '/secure7/login.php', '2019-04-12 22:00:10'),
(610, '127.0.0.1', 'peter00', '/secure7/login.php', '2019-04-12 22:04:58'),
(611, '127.0.0.1', 'peter00', '/secure7/login.php', '2019-04-12 22:06:30'),
(612, '127.0.0.1', 'peter00', '/secure7/login.php', '2019-04-12 22:07:37'),
(613, '127.0.0.1', 'peter00', '/secure--master/login.php', '2019-04-12 22:10:53');

-- --------------------------------------------------------

--
-- Table structure for table `forum`
--

CREATE TABLE `forum` (
  `post_id` int(11) NOT NULL,
  `username` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `testid` int(11) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum`
--

INSERT INTO `forum` (`post_id`, `username`, `testid`, `message`, `date`) VALUES
(24, 'rachel98', 2, 'not working again', '2019-04-08 03:04:51'),
(25, 'gabby', 33, 'I love this item', '2019-04-08 03:40:26'),
(26, 'gabby', 33, 'i dont like it', '2019-04-08 03:40:59'),
(40, 'peter00', 15, 'test', '2019-04-11 12:39:50'),
(41, 'peter00', 15, '&lt;a href=&rdquo;https://www.dreamhost.com/&rdquo;&gt;Awesome Hosting&lt;/a&gt;', '2019-04-11 12:49:46'),
(42, 'peter00', 15, '&lt;a href=\"http://localhost:8080/SiteX35839dhyen/login.php\"&gt;', '2019-04-11 12:50:38'),
(43, 'peter00', 15, '&lt;script&gt;\r\nalert(\"hacked\")&lt;/script&gt;', '2019-04-11 12:50:58'),
(44, 'peter00', 0, '&lt;script&gt;\r\nalert(\"hacked\")&lt;/script&gt;', '2019-04-11 12:53:17'),
(45, 'peter00', 0, '&lt;iframe src=&rdquo;http://bad-dude-hacker-mafia.com/xss-injection.php&rdquo; height=0 width=0 /&gt;', '2019-04-11 14:44:33'),
(46, 'peter00', 0, 'jnjnjn', '2019-04-12 01:23:01'),
(47, 'peter00', 15, 'jnj', '2019-04-12 01:47:07'),
(48, 'peter00', 15, '$current_timestamp', '2019-04-12 01:50:40'),
(49, 'peter00', 15, 'TEST AGIN', '2019-04-12 01:53:16'),
(50, 'peter00', 15, 'hi', '0000-00-00 00:00:00'),
(51, 'peter00', 15, 'TEST AGAIN', '0000-00-00 00:00:00'),
(52, 'peter00', 15, 'yha', '2012-04-19 00:00:00'),
(53, 'peter00', 15, 'j', '0000-00-00 00:00:00'),
(54, 'peter00', 15, 'm', '0000-00-00 00:00:00'),
(55, 'peter00', 15, 'k', '2019-04-12 02:35:02'),
(56, 'peter00', 15, 'njiujhi', '2019-04-12 18:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `od_id` int(255) NOT NULL,
  `order_idx` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`od_id`, `order_idx`, `product_id`, `quantity`, `price`) VALUES
(34, 57, 4, 1, 890),
(35, 58, 4, 1, 890),
(36, 59, 3, 1, 759),
(37, 75, 3, 1, 759);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(255) NOT NULL,
  `customer_id` int(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `date`, `total`) VALUES
(65, 2, '2019-04-08 19:40:47', 30),
(66, 2, '2019-04-08 19:41:38', 30),
(67, 2, '2019-04-08 19:41:40', 30),
(68, 2, '2019-04-08 19:41:56', 30),
(69, 2, '2019-04-08 19:43:25', 30),
(70, 2, '2019-04-08 19:43:28', 30),
(71, 2, '2019-04-08 19:43:42', 30),
(72, 2, '2019-04-08 19:43:45', 30),
(73, 2, '2019-04-08 19:44:30', 30),
(74, 2, '2019-04-08 19:44:34', 30),
(75, 2, '2019-04-08 19:48:19', 789),
(76, 33, '2019-04-08 19:57:46', 30),
(77, 33, '2019-04-08 19:59:52', 30);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double(10,2) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_id`, `name`, `image`, `description`, `quantity`, `price`, `created`, `modified`) VALUES
(3, 86390243, 'Surfacebook', '/images/surfacebook.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM 8 GB \r\nStorage 512 GB SSD\r\nBattery life Up to 12 hours', 10, 759.00, '2019-01-02 10:04:03', '2019-03-19 21:27:54'),
(4, 86352343, 'ACER', '/images/apple2.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 890.00, '2019-01-02 10:04:03', '2019-03-19 20:30:18'),
(5, 83640293, 'Mac Book', '/images/macbook3.png', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 900.00, '2019-01-02 10:04:03', '2019-03-19 20:39:43'),
(6, 80240290, 'MacBook Pro 13-inch', '/images/macbook2.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 1730.67, '2019-01-02 10:04:03', '2019-03-19 20:29:42'),
(9, 83230992, 'Mac Book 13', '/images/mac.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 0.00, '0000-00-00 00:00:00', '2019-03-19 20:29:16'),
(12, 87347205, 'Mac Book 12', '/images/applemacbookair.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 1345.00, '2019-03-18 11:16:34', '2019-03-19 20:30:07'),
(17, 86390243, 'Surfacebook', '/images/sl.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-01-02 10:04:03', '2019-03-19 21:20:56'),
(20, 863953734, 'Mac', '/images/surfacebook.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-03-19 20:56:08', '2019-03-19 21:00:22'),
(21, 863953734, 'Mac', 'images/macbook1.png', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-03-19 21:01:57', '2019-03-19 21:22:44'),
(22, 863953734, 'Mac', '/images/apple2.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-03-19 21:04:31', '2019-03-19 21:05:32'),
(23, 863953734, 'Mac', '/images/mouse.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-03-19 21:04:51', '2019-03-19 21:07:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lname` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_level` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `lname`, `username`, `address`, `country`, `number`, `password`, `access_level`) VALUES
(14, '1', 'Solomon', 'rachel98', '1, Culwell Street\r\nLiberty Heights. B23 room 4', 'United Kingdom', '07405640166', '$2y$10$c2QnL8fKmlwkC6PzgwY.S.ej5mP4cVq3/GJR5E.o3ldeC7URxgJn.', 'Customer'),
(15, 'Peter', 'Solomon', 'peter00', '1, Culwell Street, Liberty Heights. B23 room 4', 'United Kingdom', '07405640166', '$2y$10$AG/mHm8Y8htQrZqzLQ7sL.PRowvw8U2SLWobE/OeMYTLgvW9Gx/xW', 'Customer'),
(20, '1', 'Solomon', 'gabby10', '1,librty', 'irel', '257392620', '$2y$10$GOzz7ihGZlhPmpY9rS0AX.qFb.6t0oQkQB2v7PQmNgwDsWsvAAi/K', ''),
(30, '1', 'newn', 'new', 'newn', 'newn', 'newnn', '$2y$10$s4hbe8rz0xNYjcgJbO8uuePTV92uGgtSgLIiCKlTHYx0ydQgEWzGS', ''),
(31, '1', 'JNJNNJN', 'peter00KNKKMK', 'JNJJNJN', 'JNJJJJ', 'JNJJNJ', '$2y$10$PrHuEuTBwwgoJHjY9Ut/muhdYHzOkSbiMR1/6hELlWfhmoj.60wJ.', ''),
(32, 'hbhbhb', 'hbhb', 'hbhbhbh', 'hbhh', 'bbhbh', 'hbhbhhb', '$2y$10$lfsGjbTg.8W7qK562czGsecG4hX4LlK26HLRT1YZmJMn61xCowK9O', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_y`
--
ALTER TABLE `admin_y`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_login`
--
ALTER TABLE `failed_login`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`(191));

--
-- Indexes for table `forum`
--
ALTER TABLE `forum`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `testid` (`testid`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`od_id`),
  ADD KEY `order_id` (`order_idx`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_y`
--
ALTER TABLE `admin_y`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `forum`
--
ALTER TABLE `forum`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `od_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
