-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2019 at 12:23 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `address` text NOT NULL,
  `password` varchar(512) NOT NULL,
  `access_level` varchar(16) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=pending,1=confirmed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='admin and customer admins';

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `address`, `password`, `access_level`, `status`) VALUES
(1, 'sade', 'sade', 'sade', 'Admin', 1),
(30, 'admin', 'admin', 'admin', 'Admin', 1),
(31, 'new', 'new', 'new', 'Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `fakelogin`
--

CREATE TABLE `fakelogin` (
  `id` int(12) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fakelogin`
--

INSERT INTO `fakelogin` (`id`, `username`, `password`, `date`) VALUES
(3, 'rachelod98', 'bhhbhn', '2019-04-08 20:02:59'),
(6, 'kmkk', 'mlmkmk', '2019-04-08 20:02:59'),
(7, 'test', 'test', '2019-04-08 20:03:46'),
(8, 'jnjn', 'jnjnj', '2019-04-08 22:04:16'),
(9, 'test', 'test', '2019-04-08 22:04:32'),
(10, 'test', 'hhb', '2019-04-08 22:10:45'),
(11, 'test', 'jn', '2019-04-08 22:13:45'),
(12, 'test', 'jbhjjbjnb', '2019-04-09 00:32:04'),
(14, 'jn', '080eff4eef0872e72fc4394cc5831314', '2019-04-09 01:42:04'),
(15, 'rachel123', 'b67d95af4a12e68ae4b5b43e1f911fbf', '2019-04-09 01:47:04'),
(16, 'nkjnjn', 'c7b5ce6a3eab23fff0bd88b305feec23', '2019-04-09 17:25:46'),
(17, 'peter00', 'd41d8cd98f00b204e9800998ecf8427e', '2019-04-09 17:32:46'),
(18, 'ray', 'jnjnjn', '2019-04-09 20:32:41'),
(19, 'bbj', 'jnjjn', '2019-04-09 20:35:54'),
(20, 'jnj', 'cgh', '2019-04-09 20:37:47'),
(21, 'jnknkn', 'kmkkm', '2019-04-09 20:40:55'),
(22, 'kjmkm', 'cghhn', '2019-04-09 20:44:46'),
(23, 'qwer', '962012d09b8170d912f0669f6d7d9d07', '2019-04-09 21:25:36'),
(24, 'again', 'agaei', '2019-04-09 21:27:42'),
(25, 'againnjnn', 'jnnnj', '2019-04-09 21:28:49'),
(26, 'rachel98', 'jnnj', '2019-04-09 22:22:57');

-- --------------------------------------------------------

--
-- Table structure for table `forum`
--

CREATE TABLE `forum` (
  `post_id` int(11) NOT NULL,
  `username` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `testid` int(11) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum`
--

INSERT INTO `forum` (`post_id`, `username`, `testid`, `message`, `date`) VALUES
(24, 'rachel98', 2, 'not working again', '2019-04-08 03:04:51'),
(25, 'gabby', 33, 'I love this item', '2019-04-08 03:40:26'),
(26, 'gabby', 33, 'i dont like it', '2019-04-08 03:40:59'),
(31, 'rachel98', 2, '<a href=\"http://localhost:8080/SiteX35839dhyen/login.php\">\r\n   <button>Check New Product</button>\r\n</a>', '2019-04-08 20:53:11'),
(32, 'gabby', 33, '<a href=\"http://localhost:8080/SiteX35839dhyen/home.php\">\r\n   <button>Visit Google</button>\r\n</a>', '2019-04-08 20:55:02'),
(37, 'gabby', 33, '<script>\r\nalert(\"hacked\")</script>', '2019-04-08 21:17:29'),
(38, 'gabby', 33, '<script>alert(\"hacked\")</script>', '2019-04-08 21:18:18'),
(39, 'gabby', 33, '<script>alert(document.cookie)</script>', '2019-04-08 21:21:08');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `od_id` int(255) NOT NULL,
  `order_idx` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`od_id`, `order_idx`, `product_id`, `quantity`, `price`) VALUES
(34, 57, 4, 1, 890),
(35, 58, 4, 1, 890),
(36, 59, 3, 1, 759),
(37, 75, 3, 1, 759),
(38, 78, 5, 1, 900),
(39, 78, 3, 7, 759);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(255) NOT NULL,
  `customer_id` int(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `date`, `total`) VALUES
(57, 2, '2019-04-07 22:41:13', 920),
(58, 2, '2019-04-08 17:23:46', 920),
(59, 2, '2019-04-08 19:06:08', 789),
(60, 2, '2019-04-08 19:23:43', 30),
(61, 2, '2019-04-08 19:24:18', 30),
(62, 2, '2019-04-08 19:25:46', 30),
(63, 2, '2019-04-08 19:40:31', 30),
(64, 2, '2019-04-08 19:40:35', 30),
(65, 2, '2019-04-08 19:40:47', 30),
(66, 2, '2019-04-08 19:41:38', 30),
(67, 2, '2019-04-08 19:41:40', 30),
(68, 2, '2019-04-08 19:41:56', 30),
(69, 2, '2019-04-08 19:43:25', 30),
(70, 2, '2019-04-08 19:43:28', 30),
(71, 2, '2019-04-08 19:43:42', 30),
(72, 2, '2019-04-08 19:43:45', 30),
(73, 2, '2019-04-08 19:44:30', 30),
(74, 2, '2019-04-08 19:44:34', 30),
(75, 2, '2019-04-08 19:48:19', 789),
(76, 33, '2019-04-08 19:57:46', 30),
(77, 33, '2019-04-08 19:59:52', 30),
(78, 37, '2019-04-12 00:24:05', 6243);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double(10,2) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_id`, `name`, `image`, `description`, `quantity`, `price`, `created`, `modified`) VALUES
(3, 86390243, 'Surfacebook', '/images/surfacebook.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM 8 GB \r\nStorage 512 GB SSD\r\nBattery life Up to 12 hours', 10, 759.00, '2019-01-02 10:04:03', '2019-03-19 21:27:54'),
(4, 86352343, 'ACER', '/images/apple2.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 890.00, '2019-01-02 10:04:03', '2019-03-19 20:30:18'),
(5, 83640293, 'Mac Book', '/images/macbook3.png', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 900.00, '2019-01-02 10:04:03', '2019-03-19 20:39:43'),
(6, 80240290, 'MacBook Pro 13-inch', '/images/macbook2.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 1730.67, '2019-01-02 10:04:03', '2019-03-19 20:29:42'),
(9, 83230992, 'Mac Book 13', '/images/mac.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 0.00, '0000-00-00 00:00:00', '2019-03-19 20:29:16'),
(12, 87347205, 'Mac Book 12', '/images/applemacbookair.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 1345.00, '2019-03-18 11:16:34', '2019-03-19 20:30:07'),
(17, 86390243, 'Surfacebook', '/images/sl.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-01-02 10:04:03', '2019-03-19 21:20:56'),
(20, 863953734, 'Mac', '/images/surfacebook.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-03-19 20:56:08', '2019-03-19 21:00:22'),
(21, 863953734, 'Mac', 'images/macbook1.png', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-03-19 21:01:57', '2019-03-19 21:22:44'),
(22, 863953734, 'Mac', '/images/apple2.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-03-19 21:04:31', '2019-03-19 21:05:32'),
(23, 863953734, 'Mac', '/images/mouse.jpg', 'Product features\r\nMacOS\r\nIntel Core i5 Processor\r\nRAM: 8 GB / Storage: 512 GB SSD\r\nBattery life: Up to 12 hours', 10, 759.00, '2019-03-19 21:04:51', '2019-03-19 21:07:47');

-- --------------------------------------------------------

--
-- Table structure for table `track`
--

CREATE TABLE `track` (
  `id` int(11) NOT NULL,
  `IP` text CHARACTER SET utf8,
  `username` varchar(255) NOT NULL,
  `user_url` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `track`
--

INSERT INTO `track` (`id`, `IP`, `username`, `user_url`, `date`) VALUES
(30, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-03-27 22:50:43'),
(31, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-03-27 22:50:45'),
(32, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-03-27 22:50:57'),
(33, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-03-27 22:51:35'),
(36, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-03-28 13:42:20'),
(37, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-03-28 16:29:39'),
(38, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-03-30 16:25:59'),
(39, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-03-30 16:26:20'),
(40, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-02 22:05:12'),
(41, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-04 17:00:12'),
(42, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-04 17:00:24'),
(43, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-05 02:07:50'),
(44, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-05 02:07:56'),
(45, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-05 02:07:59'),
(47, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 22:38:16'),
(48, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 22:45:59'),
(49, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 22:46:14'),
(50, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 22:46:16'),
(51, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 22:46:26'),
(52, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 23:02:58'),
(53, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 23:26:55'),
(54, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 23:27:01'),
(55, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 23:41:52'),
(56, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 23:48:30'),
(57, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-07 23:51:07'),
(58, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 00:47:58'),
(59, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 01:00:34'),
(60, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 02:04:38'),
(61, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 02:32:45'),
(62, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 02:36:47'),
(63, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 02:37:04'),
(64, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 02:38:51'),
(65, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 02:39:10'),
(66, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 02:40:06'),
(67, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 02:40:13'),
(68, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 02:40:47'),
(69, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 02:41:24'),
(70, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 15:02:35'),
(71, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 17:20:35'),
(72, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 17:20:51'),
(73, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 17:21:18'),
(74, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 19:05:41'),
(75, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 19:05:58'),
(76, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 19:06:13'),
(77, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 19:16:00'),
(78, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 19:51:21'),
(79, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 19:52:06'),
(80, '127.0.0.1', 'rachel98', '/SiteX/homepage.php', '2019-04-08 19:52:55'),
(81, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 19:54:35'),
(82, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:07:40'),
(83, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:11:38'),
(84, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:13:43'),
(85, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:15:21'),
(86, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:15:48'),
(87, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:17:37'),
(88, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:18:39'),
(89, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:18:43'),
(90, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:19:21'),
(91, '127.0.0.1', 'gabby', '/SiteX/homepage.php', '2019-04-08 20:20:57'),
(92, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-11 11:27:46'),
(93, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-11 11:58:52'),
(94, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-11 12:00:42'),
(95, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-11 12:00:52'),
(96, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-11 12:02:51'),
(97, '127.0.0.1', '', '/SiteX/homepage.php', '2019-04-11 14:32:40'),
(98, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-11 14:35:24'),
(99, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-11 15:30:47'),
(100, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-11 21:34:31'),
(101, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-12 00:23:46'),
(102, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-12 00:23:49'),
(103, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-12 00:24:09'),
(104, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-12 00:24:44'),
(105, '127.0.0.1', 'peter00', '/SiteX/homepage.php', '2019-04-12 17:35:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(255) NOT NULL,
  `number` int(11) NOT NULL,
  `password` varchar(512) NOT NULL,
  `access_level` varchar(16) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=pending,1=confirmed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='admin and customer users';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `lname`, `username`, `address`, `country`, `number`, `password`, `access_level`, `status`) VALUES
(2, 'Rachael', 'Solomon', 'rachel98', '1, culwell street.', 'United Kingdom', 74527930, 'rachel123', 'Customer', 1),
(33, 'Gabby', 'Solomon', 'gabby', '3, Bellgree Rise, Tyrrelstown. Dublin 15 ROI', 'Republic of Ireland', 2147483647, 'gabby123', 'Customer', 1),
(37, 'Peter', 'Solomon', 'peter00', '1, Culwell Street, Liberty Heights. B23 room 4', 'United Kingdom', 2147483647, 'peter', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `fakelogin`
--
ALTER TABLE `fakelogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forum`
--
ALTER TABLE `forum`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `testid` (`testid`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`od_id`),
  ADD KEY `order_id` (`order_idx`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track`
--
ALTER TABLE `track`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `fakelogin`
--
ALTER TABLE `fakelogin`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `forum`
--
ALTER TABLE `forum`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `od_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `order_f` FOREIGN KEY (`order_idx`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `customer_f` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
