<?php require('conn.php');
    ?>
    <a href="home.php">First Image</a>
    <a href="back.php">Second Image</a>
    <a href="laptop.php">Third Image</a>

    <!DOCTYPE html>
    <html>
    	<head>
    		<title>Shopping Cart</title>
        <h3>Free affordable laptop<h3>
    		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    		<link rel="stylesheet" type="text/css" href="index.css">
    		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    	</head>
    	<body>
			<?php
				$query = "SELECT * FROM products ORDER BY id ASC";
				$result = mysqli_query($connection, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>

          <div class='col-sm-6 col-md-4'>
              <div class='thumbnail'>
                  <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['image'] ?>"></a>
                  <div class="caption">
                  <h4 class="text-dark"><p>Product Number: <?php echo $row['product_id'] ?></p></h4>
      						<h4 class="text-info"><?php echo $row["name"]; ?></h4>
      						<h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>
                  <h4 class="text-dark"><p><?php echo $row['description'] ?></p></h4>
      						<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />
      						<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />
                </div>
            </div>
          </div>
      <?php } ?>
      </div>
      <?php
      }
      ?>
      <img src = "http://localhost:8080/SiteX/testcheck.php"alt = "">

      	</body>
      </html>
