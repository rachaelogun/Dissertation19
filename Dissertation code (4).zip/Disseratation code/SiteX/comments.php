<?php

function setcomments($connection){
  if (isset($_POST['commentsubmit'])){
    $uid = $_POST['uid'];
    $date = $_POST['date'];
    $message = $_POST['message'];

    $sql = "INSERT INTO comments (uid, date, message) VALUES ('".$uid."', '".$date."', '".$message."')";
    $result = $connection->query($sql);
  }
}

function getcomments($connection){
  $sql = "SELECT * FROM comments";
  $result = $connection->query($sql);
  while($row = $result->fetch_assoc()){
    echo "<div class='comment-box'><p>";
    echo $row['uid']."<br>";
    echo $row['date']."<br>";
    echo nl2br($row['message']);
    echo "</p>
    <form class='delete-form' method='POST' action='".deletecomments($connection)."'>
    <input type='hidden' name='cid' value='".$row['cid']."'>
    <button type='submit' name='commentdelete'>Delete</button>
    </form>
    <form class='edit-form' method='POST' action='editcomment.php'>
    <input type='hidden' name='cid' value='".$row['cid']."'>
    <input type='hidden' name='uid' value='".$row['uid']."'>
    <input type='hidden' name='date' value='".$row['date']."'>
    <input type='hidden' name='message' value='".$row['message']."'>
    <button>Edit</button>
    </form>
    </div>";
  }
}

function editcomments($connection){
  if (isset($_POST['commentsubmit'])){
    $cid = $_POST['cid'];
    $uid = $_POST['uid'];
    $date = date('Y-m-d H:i:s');
    $message = $_POST['message'];

    $sql = "UPDATE comments SET date='$date', message='$message' WHERE cid='$cid'";
    $result = $connection->query($sql);
    header("Location: home.php");
  }
}

function deletecomments($connection){
  if (isset($_POST['commentdelete'])){
    $cid = $_POST['cid'];

    $sql = "DELETE FROM comments WHERE cid='$cid'";
    $result = $connection->query($sql);
    header("Location: home.php");
  }
}

function getlogin($connection){
  if (isset($_POST['loginsubmit'])){
  $username = $_POST['username'];
  $password = $_POST['password'];

  $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
  $result = $connection->query($sql);
  if (mysqli_num_rows($result) > 0){
    if($row = $result->fetch_assoc()){
      $SESSION['id'] =$row['id'];
      header("Location: home.php?loginsucess");
      exit();
    }
  }else{
      header("Location: home.php?loginfailed");
      exit();
    }
  }
}

  function userlogout(){
    if (isset($_POST['logoutsubmit'])){
      session_start();
      session_destroy();
      header("Location: home.php");
      exit();
    }
}
