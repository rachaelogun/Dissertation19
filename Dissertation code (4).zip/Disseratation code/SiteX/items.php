<?php
// core configuration

include_once "config.php";
// set page title
$page_title="Customer";
// include page header HTML
include_once 'header.php';
echo "<div class='col-md-12'>";
          echo "<div class='alert alert'>";
            echo "<strong>Hi " . $_SESSION['username'] . ", welcome back!</strong>";
        echo "</div>";
echo "</div>";
//session_start();

$connect = mysqli_connect("localhost", "root", "", "login_system");

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			array_push($_SESSION['shopping_cart'], $item_array);
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="homepage.php"</script>';
			}
		}
	}
}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Webslesson Demo | Simple PHP Mysql Shopping Cart</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="index.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</head>
	<body>
			<?php
				$query = "SELECT * FROM products ORDER BY id ASC";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
        <form method="post" action="cart.php?action=add&id=<?php echo $row["id"]; ?>">
            <div class='col-sm-6 col-md-4'>
              <div class='thumbnail'>
                <a href="item.php?view=<?php echo $row['id']; ?>"</a>
                	<img src="<?php echo $row['image']; ?>" alt="<?php echo $row['image'] ?>"></a>
                  <div class="caption">
            <h4 class="text-dark"><p>Product Number: <?php echo $row['product_id'] ?></p></h4>
						<h4 class="text-info"><?php echo $row["name"]; ?></h4>
						<h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>
            <h4 class="text-dark"><p><?php echo $row['description'] ?></p></h4>
						<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />
						<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />
						<select name='quantity' class='form-control cart-quantity m-b-10px cart-quantity-dropdown'><option selected>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option></select>
						<input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />
          </div>
      </div>
    </div>
  </form>
<?php } ?>
</div>
<?php
}
?>
	</body>
</html>
