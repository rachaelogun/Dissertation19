<?php
// core configuration
include_once "config.php";
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$update = true;
	$record = mysqli_query($connection, "SELECT * FROM users WHERE id=$id");

	if (@count($record) == 1 ) {
		$n = @mysqli_fetch_array($record);
		$name = $n['name'];
		$lname = $n['lname'];
		$address = $n['address'];
		$country = $n['country'];
		$number = $n['number'];
	}

}
// set page title
$page_title="Profile";
// include page header HTML
include_once 'header.php';

?>

<!DOCTYPE html>
<html>
<head>
	<title> Update Profile</title>
</head>
<body>
	<?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>

<?php
	$username=$_SESSION["username"];//session id of the current user
	$query= mysqli_query($connection, "SELECT * FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id
 ?>


	<?php while (	$row = @mysqli_fetch_array($query));
{ ?>
	<?php

  //include_once('connection.php'); //For connecting the database

    $username=$_SESSION["username"];//session id of the current user
    $query= mysqli_query($connection, "SELECT * FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id

    // to display the row of the database as string not as resource id, we must use functions such as mysql_fetch_assoc() or mysql_fetch_row(). They have return type of array
    $row = @mysqli_fetch_array($query);
?>
<html>
 <body>
 <div class="container">
	 <div class="row">
		 <div class="col-sm-12">
			 <div class="jumbotron">
				 <link rel="stylesheet" type="text/css" href="check.css">
				 <div class="d-flex">
				 	 <form action="" method="post">
				 		<label>
				 			<span class="fname">First Name <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo $row['name']; ?>" />
				 		</label>
				 		<label>
				 			<span class="lname">Last Name <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo $row['lname']; ?>" />
				 		</label>
				 		<label>
				 			<span class="address">Address <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo $row['address']; ?>" />
				 		</label>
				 		<label>
				 			<span class="country">Country <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo $row['country']; ?>" />
				 		</label>
				 		<label>
				 			<span class="number">Phone Number <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo $row['number']; ?>" />
				 		</label>

				 <div align = "right">
				 	<a href='userprofile.php?edit=<?php echo $row['id']; ?>' class="btn btn-default";><span class="glyphicon glyphicon-edit"></span> Edit User Profile</a>
				 </div>
				 	<?php } ?>
				 </form>

				 </body>
				 </html>
