<?php
$connection = mysqli_connect('localhost', 'root', '', 'login_system');
        $username = "";
        if (isset($_POST['register'])) {
        	$username = $_POST['username'];
          $address = $_POST['address'];
        	$password = $_POST['password'];

        	$sql_u = "SELECT * FROM users WHERE username='$username'";
        	$res_u = mysqli_query($connection, $sql_u);

        	if (mysqli_num_rows($res_u) > 0) {
        	  $name_error = "$username has already been taken, Try a different username";
        	}else{
                 $query = "INSERT INTO users (username, password, address)
            	    	  VALUES ('$username', '$password', '$address')";
                 $results = mysqli_query($connection, $query);
                 if ($results){
                 echo "<script type='text/javascript'>alert('Registered Successfully')
                window.location.href = 'login.php';
                </script>";
                 exit();
               }
        	}
        }
      ?>
