<?php
// core configuration
include('productsession.php');
	if (isset($_GET['view'])) {
		$id = $_GET['view'];
		$record = mysqli_query($db, "SELECT * FROM products WHERE id=$id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$name = $n['name'];
			$description = $n['description'];
      $price = $n['price'];
		}
	}

?>

<!DOCTYPE HTML>
<html>
<head>
    <title>PDO - Read One Record - PHP CRUD Tutorial</title>

    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

</head>
<body>
    <!-- container -->
    <div class="container">
        <div class="page-header">
            <h1>Read Product</h1>
        </div>

        <?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>
<?php $results = mysqli_query($db, "SELECT * FROM products"); ?>
	<?php while ($row = mysqli_fetch_array($results)) { ?>
	<?php } ?>


        <!--we have our html table here where the record will be displayed-->
        <table class='table table-hover table-responsive table-bordered'>
          <form method="post" action="productsession.php" >
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <tr>
                <td>Name</td>
                <td><?php echo $name; ?></td>
            </tr>
            <tr>
                <td>Description</td>
                <td><?php echo $description; ?></td>
            </tr>
            <tr>
                <td>Price</td>
                <td><?php echo $price; ?></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <a href='products.php' class='btn btn-danger'>Back to read products</a>
                </td>
            </tr>
        </table>
    </div> <!-- end .container -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>
