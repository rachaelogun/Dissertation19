<?php
// core configuration
include_once "config.php";
// set page title
$page_title="Order Details";
// include page header HTML
include_once 'header.php';
//session_start();
$connect = mysqli_connect("localhost", "root", "", "login_system");

$item_id =  0;
$quantity = 0;
$price = 0.0;

$total = 0.0;
// getting values from array
if(!empty($_SESSION["shopping_cart"]))
{
	$total = 0;
	foreach($_SESSION["shopping_cart"] as $keys => $values)
	{
	$total = $total + ($values["item_quantity"] * $values["item_price"]);
	}
}
// get the user id, i was able to use your style because i can reference by column such as $n['id'];
$username = $_SESSION['username'];
/*
$record = mysqli_query($connection, "SELECT id FROM users WHERE username = $username");

if (@count($record) == 1 ) {
  $n = @mysqli_fetch_array($record);
$userid = $n['id'];

}
*/
$userid=0;
$useridsql = "SELECT id FROM users WHERE username = '$username'";
$query_id = mysqli_query($connection, $useridsql);
$result = mysqli_num_rows($query_id);

//$query_id = $connection -> mysqli_query($useridsql);
if ($result == 1){
//if($query_id -> num_rows > 0){
  while($row = mysqli_fetch_assoc($query_id)){
    $userid = $row['id'];
  }
}

echo $userid;

//get the order id, you need to transform that into your style query,
// i was not able because this query is not actually a value from a table but is an
// aritmetic calculation on the table that returns me a value, and with your style I dunno how to
// $the sql_id query takes the maximum order_id from the orders table at the moment
// so that we can store the order_id we will use which will be $order_id = $order_id + 1
// because it is a value which has not being used in the table yet for our primary key
// remember that you need to style also the second query to adjust the auto_increment value
$sql_id = "SELECT MAX(order_id) FROM orders";
//$query_id = $connection -> query($sql_id);
$query_id = mysqli_query($connection, $sql_id);
$row = mysqli_fetch_assoc($query_id);
//$row = $query_id -> fetch_assoc();
$order_id = $row["MAX(order_id)"] + 1;
$change_id = "ALTER TABLE orders AUTO_INCREMENT=".$order_id;
mysqli_query($connection, $change_id);
//$connection->query($change_id);

$num = 25;
$percentage = 20;
$num += $num*($percentage/100);
$num = round($num, 1);      // 4
$num = sprintf('%0.2f', $num);
$final = $total + $num;


// you need to change this query into your style by inserting the values we discovered in the previous query
$sql = "INSERT INTO orders (order_id, customer_id, date, total) VALUES ($order_id, $userid, CURRENT_TIMESTAMP, $final)";
//$sql = $connection -> query($sql);
mysqli_query($connection, $sql);


if(!empty($_SESSION["shopping_cart"]))
{
  $item_id = 0;
  $quantity = 0;
  $price = 0.0;
	foreach($_SESSION["shopping_cart"] as $keys => $values)
	{
    $item_id =  $values["item_id"];
  	$quantity = $values["item_quantity"];
  	$price = $values["item_price"];
    echo $item_id;

    //Notice that here we are inside a loop and youre going to
    //get the future od_id (you need to change this into your style as well)
    // same as before, but in this case we are in a loop because in this table we need
    // to add many rows dependent on how many product are in the order, so for each product in the shopping Cart
    // the code is selecting the maximum value of od_id int the table, like before, adding one to it as it is unused and
    // use that value for the first product id in our query, so for the code will run multiple times based on
    // how many product. it will loop from line 69 (foreach .... ) to line 92

    $od_id = "SELECT MAX(od_id) FROM orderdetails";
    $queryod_id = mysqli_query($connection, $od_id);

    //$queryod_id = $connection -> query($od_id);
    //$row = $queryod_id -> fetch_assoc();
    $row = mysqli_fetch_assoc($queryod_id);
    $od_id = $row["MAX(od_id)"] + 1;
    $changeod_id = "ALTER TABLE orders AUTO_INCREMENT=".$od_id;
    //$connection->query($changeod_id);
    mysqli_query($connection, $changeod_id);

    // you need to change this into your style as well, here adding the actual row into orderdetails
    // as we have everything ready
    $order = "INSERT INTO orderdetails (od_id, order_idx, product_id, quantity, price) VALUES ($od_id, $order_id, $item_id, $quantity, $price)";
    $order = $connection -> query($order);

    //mysqli_query($connection, $order);
	}
  header("location: place_order.php?action=clear");
  exit();
}

header("location: place_order.php?action=clear");
exit();


?>
