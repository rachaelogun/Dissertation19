<?php
session_start();
// Create connection
$connection = new mysqli ('localhost', 'root', 'Solomonsade123');
if (!$connection){
  die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'login_system');
if (!$select_db){
  die("Database Selection Failed" . mysqli_error($connection));
  }
  ?>
