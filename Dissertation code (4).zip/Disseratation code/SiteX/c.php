<?php
 require('conn.php');

if (isset($_POST['username']) and isset($_POST['password'])){

// Assigning POST values to variables.
$username = $_POST['username'];
$password = $_POST['password'];
$name = $_POST['name'];
$lname = $_POST['lname'];

if ($username != "admin"){
// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `users` WHERE username='$username' and Password='$password'";

$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$count = mysqli_num_rows($result);

if ($result -> num_rows > 0){
//echo "Login Credentials verified";
$_SESSION['admin'] = false;
$_SESSION['loggedIn'] = true;
$_SESSION['username']=$username;
header("Location: create.php");

}
else{
   echo "<script type='text/javascript'>alert('The username or password you entered is incorrect')
  window.location.href = 'track.php?loginfailed';
  </script>";
}
}
else {
  $query = "SELECT * FROM `admin` WHERE username='$username' and password='$password'";
  $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
  $count = mysqli_num_rows($result);

  if ($result -> num_rows > 0){
  //echo "Login Credentials verified";
  $_SESSION['admin'] = true;
  $_SESSION['loggedIn'] = true;
  $_SESSION['username']=$username;
  header("Location: admindex.php");

  }
  else{
     echo "<script type='text/javascript'>alert('The username or password you entered is incorrect')
    window.location.href = 'login.php?loginfailed';
    </script>";
  }
  }
}
if (isset($_GET['view'])) {
  $id = $_GET['view'];
  $record = mysqli_query($db, "SELECT * FROM users WHERE id=$id");

  if (@count($record) == 1 ) {
    $n = @mysqli_fetch_array($record);
    $username = $n['username'];

  }
}
