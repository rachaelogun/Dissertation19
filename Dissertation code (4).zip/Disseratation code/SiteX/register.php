<?php
// set page title
$page_title = "Register";

// include page header HTML
include_once "loginhead.php";
include('registration.php');

echo "<div class='col-md-12'>";

   ?>
   <div class="alert alert-danger text-center" style= "center" role="alert">
     <?php if (isset($name_error)): ?>
     <?php echo $name_error; ?>
   <?php endif ?>
   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
   <form action='register.php' method='post' >

       <table class='table table-responsive'>

           <tr>
               <td class='width-30-percent'>Username</td>
               <td><input type='text' name='username' class='form-control' ></td>
           </tr>

           <tr>
               <td>Address</td>
               <td><textarea name='address' class='form-control' ></textarea></td>
           </tr>

           <tr>
               <td>Password</td>
               <td><input type='password' name='password' class='form-control' </td>
           </tr>

           <tr>
               <td></td>
               <td>
                   <button type="submit"  name="register" class="btn btn-primary" value='Register'>
                       <span class="glyphicon glyphicon-plus"></span> Register
                   </button>
               </td>
           </tr>

       </table>
   </form>
   <?php
echo "</div>";

// include page footer HTML
include_once "footer.php";
?>
