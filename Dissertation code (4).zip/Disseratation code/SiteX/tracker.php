
  <?php
  // core configuration
  require("config.php");
  // set page title
  //session_start();
  $connection = new mysqli ('localhost', 'root', '');
  if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
  }
  $select_db = mysqli_select_db($connection, 'login_system');
  if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
    }
  // get the user id, i was able to use your style because i can reference by column such as $n['id'];
 $username = $_SESSION['username'];


  $sql_id = "SELECT MAX(id) FROM track";
  //$query_id = $connection -> query($sql_id);
  $query_id = mysqli_query($connection, $sql_id);
  $row = mysqli_fetch_assoc($query_id);
  //$row = $query_id -> fetch_assoc();
  $id = $row["MAX(id)"] + 1;
  $change_id = "ALTER TABLE track AUTO_INCREMENT=".$id;
  mysqli_query($connection, $change_id);
  $username = $username;
  $IP = $_SERVER['REMOTE_ADDR'];

  $user_url = $_SERVER["PHP_SELF"];

  // you need to change this query into your style by inserting the values we discovered in the previous query
  $sql = "INSERT INTO track (id, user_url, IP, username, date) VALUES ('$id', '$user_url', '$IP','$username', CURRENT_TIMESTAMP)";
  //$sql = $connection -> query($sql);
  mysqli_query($connection, $sql);

  $query = "SELECT count (*) FROM track WHERE this_page = '$user_url'";
  $result = mysqli_query($connection, $query);
  $views = @mysqli_fetch_array($result, 0, "count(*)");
  echo $views;
  ?>
