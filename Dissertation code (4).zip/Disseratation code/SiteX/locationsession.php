<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'login_system');

	// initialize variables
	$username = "";
	$IP = "";
	$user_url= "";
	$date = "";
	$id = 0;
	$update = false;

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM track WHERE id=$id");
	$_SESSION['message'] = "User deleted!";
	header('location: location.php');
}

	$results = mysqli_query($db, "SELECT * FROM track");
?>
