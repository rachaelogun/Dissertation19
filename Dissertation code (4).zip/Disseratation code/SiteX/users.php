<?php
include('usersession.php');

	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM users WHERE id=$id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$username = $n['username'];
			$address = $n['address'];
      $access_level = $n['access_level'];

		}

	}

?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Users</title>

    <!-- Latest compiled and minified Bootstrap CSS -->
		<link rel="stylesheet" type="text/css" href="product.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

    <!-- custom css -->
    <style>
    .m-r-1em{ margin-right:1em; }
    .m-b-1em{ margin-bottom:1em; }
    .m-l-1em{ margin-left:1em; }
    .mt0{ margin-top:0; }
    </style>

</head>
<body>
    <!-- container -->
    <div class="container">

        <div class="page-header">
            <h1>Users</h1>
        </div>

				<?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>

<?php $results = mysqli_query($db, "SELECT * FROM users");
//$rowcount = mysqli_num_rows($results);
echo "<a href='createusers.php' class='btn btn-primary m-b-1em'>Create New User</a>";
//check if more than 0 record found
    //    if($rowcount>0){
					echo "<table class='table table-hover table-responsive table-bordered'>";//start table
              //creating our table heading
              echo "<tr>";
                  echo "<th>ID</th>";
                  echo "<th>Username</th>";
                  echo "<th>Address</th>";
                  echo "<th>Access Level</th>";
                  echo "<th>Action</th>";
              echo "</tr>";

while ($row = mysqli_fetch_array($results)) {
	//extract ($row);

    // creating new table row per record
    echo "<tr>";
      echo "<td>{$row['id']}</td>";
				echo "<td>{$row['username']}</td>";
				echo "<td>{$row['address']}</td>";
				echo "<td>{$row['access_level']}</td>";
		echo "<td>";
				// read one record
				echo "<a href='viewusers.php?view= {$row['id']}' class='btn btn-info m-r-1em'>View</a>";

				// we will use this links on next part of this post
				echo "<a href='editusers.php?edit= {$row['id']}' class='btn btn-primary m-r-1em'>Edit</a>";

				// we will use this links on next part of this post
				echo "<a href='usersession.php?del={$row['id']}'  class='btn btn-danger'>Delete</a>";
		echo "</td>";
        echo "<tr>";
			}
			echo "</table>";
//}
		//	else{
  //          echo "<div class='alert alert-danger'>No records found.</div>";
  //      }
        ?>
    </div> <!-- end .container -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<script type='text/javascript'>
// confirm record deletion
function delete_user( id ){

    var answer = confirm('Are you sure?');
    if (answer){
        // if user clicked ok,
        // pass the id to delete.php and execute the delete query
        window.location = 'usersession.php?del={$row['id']}';
    }
}
</script>
</body>
</html>
