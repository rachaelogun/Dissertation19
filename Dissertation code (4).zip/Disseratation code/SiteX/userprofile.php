<?php
// core configuration
include('config.php');
	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$record = @mysqli_query($connection, "SELECT * FROM users WHERE id=$id");

		if (@count($record) == 1 ) {
					$n = @mysqli_fetch_array($record);
					$name = $n['name'];
					$lname = $n['lname'];
					$address = $n['address'];
					$country = $n['country'];
					$number = $n['number'];
							}

	}
	// set page title
	$page_title="Update Profile";
	// include page header HTML
	//include_once 'header.php';

	?>
<!DOCTYPE html>
<html>
<head>
	<title> Update Profile</title>
	<link rel="stylesheet" type="text/css" href="../css/profile.css">
</head>
<body>
	<?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>

<?php $results = @mysqli_query($connection, "SELECT * FROM users"); ?>
<?php while ($row = mysqli_fetch_array($results)) { ?>

<?php } ?>

<html>
 <body>
 <div class="container">
	 <div class="row">
		 <div class="col-sm-12">
			 <div class="jumbotron">
				 <link rel="stylesheet" type="text/css" href="check.css">
				 <div class="d-flex">
					 <form method="post" action="profilesession.php" >
						<input type="hidden" name="id" value="<?php echo $id; ?>">

						<div class="input-group">
							<label>Name</label>
							<input type="text" name="name" value="<?php echo $name; ?>">
						</div>
							<div class="input-group">
								<label>Last Name</label>
								<input type="text" name="lname" value="<?php echo $lname; ?>">
							</div>
						<div class="input-group">
							<label>Address</label>
							<input type="text" name="address" value="<?php echo $address; ?>">
						</div>
						<div class="input-group">
							<label>Country</label>
							<input type="text" name="country" value="<?php echo $country; ?>">
						</div>
						<div class="input-group">
							<label>Phone Number</label>
							<input type="text" name="number" value="<?php echo $number; ?>">
						</div>
						<div class="input-group">

							<?php if ($update == true): ?>
								<button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
							<?php else: ?>
								<button class="btn" type="submit" name="save" >Save</button>
							<?php endif ?>
						</div>
					</form>
					</body>
					</html>
