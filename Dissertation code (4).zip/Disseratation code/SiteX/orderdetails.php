<?php
include('ordersession.php');

	if (isset($_GET['edit'])) {
		$order_id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM orders WHERE order_id =$order_id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$customer_id = $n['customer_id'];
			$date = $n['date'];
      $total = $n['total'];
      $date = $n['date'];

		}

	}

?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Orders</title>

    <!-- Latest compiled and minified Bootstrap CSS -->
		<link rel="stylesheet" type="text/css" href="product.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

    <!-- custom css -->
    <style>
    .m-r-1em{ margin-right:1em; }
    .m-b-1em{ margin-bottom:1em; }
    .m-l-1em{ margin-left:1em; }
    .mt0{ margin-top:0; }
    </style>

</head>
<body>
    <!-- container -->
    <div class="container">

        <div class="page-header">
            <h1>Orders</h1>
        </div>

				<?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>

<?php $results = mysqli_query($db, "SELECT * FROM orders");
//$rowcount = mysqli_num_rows($results);
//check if more than 0 record found
    //    if($rowcount>0){
					echo "<table class='table table-hover table-responsive table-bordered'>";//start table
              //creating our table heading
              echo "<tr>";
                  echo "<th>ID</th>";
                  echo "<th>Customer ID</th>";
                  echo "<th>Total Cost</th>";
                  echo "<th>Accessed</th>";
                  echo "<th>Action</th>";
              echo "</tr>";

while ($row = @mysqli_fetch_array($results)) {
	//extract ($row);

    // creating new table row per record
    echo "<tr>";
      echo "<td>{$row['order_id']}</td>";
				echo "<td>{$row['customer_id']}</td>";
				echo "<td>{$row['total']}</td>";
				echo "<td>{$row['date']}</td>";
		echo "<td>";
				// we will use this links on next part of this post
				echo "<a href='locationsession.php?del={$row['order_id']}'  class='btn btn-danger'>Delete</a>";
		echo "</td>";
        echo "<tr>";
			}
			echo "</table>";

        ?>
    </div>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<script type='text/javascript'>
function delete_user(order_id ){

    var answer = confirm('Are you sure?');
    if (answer){
        // if user clicks ok, the id for the deleted item will be accomplished
        window.location = 'locationsession.php?del={$row['order_id']}';
    }
}
</script>
</body>
</html>
