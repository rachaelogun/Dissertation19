
$item_id =  0;
$quantity = 0;
$price = 0.0;

$total = 0.0;
// getting values from array
if(!empty($_SESSION["shopping_cart"]))
{
	$total = 0;
	foreach($_SESSION["shopping_cart"] as $keys => $values)
	{
  $item_id =  $values["item_id"];
	$quantity = $values["item_quantity"];
	$price = $values["item_price"];

	$total = $total + ($values["item_quantity"] * $values["item_price"]);
	}
}

//get user id
$useridsql = "SELECT * FROM client WHERE account_num =".$_SESSION['username'];
$query_id = $connection -> query($useridsql);
if($query_id -> num_rows > 0){
  while($row = mysqli_fetch_assoc($query_id)){
    $userid = $row['id'];
  }
}
//get the future id
$sql_id = "SELECT MAX(order_id) FROM orders";
$query_id = $connection -> query($sql_id);
$row = $query_id -> fetch_assoc();
$order_id = $row["MAX(order_id)"] + 1;
$change_id = "ALTER TABLE orders AUTO_INCREMENT=".$order_id;
$connection->query($change_id);

//$total = $total + ($values["item_quantity"] * $values["item_price"]);
$num = 25;
$percentage = 20;
$num += $num*($percentage/100);
$num = round($num, 1);      // 4
$num = sprintf('%0.2f', $num);
$final = $total + $num;

$sql = "INSERT INTO orders (order_id, customer_id, date, total) VALUES ($order_id, $userid, CURRENT_TIMESTAMP, $final)";
$sql = $connection -> query($sql);
//$result = mysqli_query($connection, $query)

//get the future od_id
$od_id = "SELECT MAX(od_id) FROM orderdetails";
$queryod_id = $connection -> query($od_id);
$row = $queryod_id -> fetch_assoc();
$od_id = $row["MAX(od_id)"] + 1;
$changeod_id = "ALTER TABLE orders AUTO_INCREMENT=".$od_id;
$connection->query($changeod_id);


$order = "INSERT INTO orderdetails (od_id, order_idx, product_id, quantity, price) VALUES ($od_id, $order_id, $item_id, $item_quantity, $item_price])";
$order = $connection -> query($order);
