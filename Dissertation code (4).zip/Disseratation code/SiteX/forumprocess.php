<?php
$page_title = 'PHP Process Error';
session_start();

function fail($str)
{
echo "<p>Please enter a $str.</p>";
echo "<p><a href='post.php'>Post Message</a>";
exit();
}

if(isset($_POST['message']))
{
// Statements to be inserted here (step 5).
// Statements to be inserted here (step 6).
// Statements to be inserted here (step 7).
}
if (!empty( $_POST['message'] ) )
{
  $message = addslashes($_POST['message'] ) ; }
else {
  fail('message') ;
}
require ('connect_db.php') ;
$username = $_SESSION['username'];

$userid=0;
$useridsql = "SELECT id FROM users WHERE username = '$username'";
$query_id = mysqli_query($connection, $useridsql);
$result = mysqli_num_rows($query_id);

//$query_id = $connection -> mysqli_query($useridsql);
if ($result == 1){
//if($query_id -> num_rows > 0){
  while($row = mysqli_fetch_assoc($query_id)){
    $userid = $row['id'];
  }
}

echo $userid;

$sql_id = "SELECT MAX(post_id) FROM forum";
//$query_id = $connection -> query($sql_id);
$query_id = mysqli_query($connection, $sql_id);
$row = mysqli_fetch_assoc($query_id);
//$row = $query_id -> fetch_assoc();
$post_id = $row["MAX(post_id)"] + 1;
$change_id = "ALTER TABLE forum AUTO_INCREMENT=".$post_id;
mysqli_query($connection, $change_id);
//$connection->query($change_id);
$username = $username;

$sql = "INSERT INTO forum (post_id, testid, username, message, date) VALUES
('$post_id', '$userid', '$username', '$message', NOW())";
$result = mysqli_query ($connection, $sql);
if ( mysqli_affected_rows( $connection ) != 1 )
{
echo '<p>Error</p>'.mysqli_error( $connection ) ;
mysqli_close($connection);
}
else
{
mysqli_close($connection);
header('Location: forum.php');
}
