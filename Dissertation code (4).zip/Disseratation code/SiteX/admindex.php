<?php
// core configuration
include_once "config.php";


// set page title
$page_title="Admin";

// include page header HTML
include 'adminhead.php';
// include page header HTML
echo "<div class='col-md-12'>";
          echo "<div class='alert alert-success'>";
            echo "<strong>Hi " . $_SESSION['username'] . ", welcome back!</strong>";
        echo "</div>";
echo "</div>";


    echo "<div class='col-md-12'>";

        // get parameter values, and to prevent undefined index notice

    echo "</div>";

// include page footer HTML
include_once 'footer.php';
?>
