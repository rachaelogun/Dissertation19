<?php
// Create connection
$connection = mysqli_connect("localhost", "root", "Solomonsade123", "login_system")
OR die (mysqli_connect_error());
?>
