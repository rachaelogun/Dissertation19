<?php
include('productsession.php');

	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM products WHERE id=$id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$name = $n['name'];
			$description = $n['description'];
      $price = $n['price'];

		}

	}

?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Check Products Records</title>

    <!-- Latest compiled and minified Bootstrap CSS -->
		<link rel="stylesheet" type="text/css" href="product.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

    <!-- custom css -->
    <style>
    .m-r-1em{ margin-right:1em; }
    .m-b-1em{ margin-bottom:1em; }
    .m-l-1em{ margin-left:1em; }
    .mt0{ margin-top:0; }
    </style>

</head>
<body>
    <!-- container -->
    <div class="container">

        <div class="page-header">
            <h1>Read Products</h1>
        </div>
				<?php if (isset($_SESSION['message'])): ?>
					<div class="msg">
						<?php
							echo $_SESSION['message'];
							unset($_SESSION['message']);
						?>
					</div>
				<?php endif ?>

			<?php $results = mysqli_query($db, "SELECT * FROM products"); ?>
			<a href="admindex.php" class="btn btn-sm btn-info"><span class="glyphicon glyphicon-home"></span> Home</a>
<a href="create.php" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-plus"></span>Create New Product</a>
<table class='table table-hover table-responsive table-bordered'>
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Description</th>
		<th>Price</th>
		<th>Action</th>
		</tr>

	<?php while ($row = mysqli_fetch_array($results)) { ?>

	<tr>
			<td><?php echo $row['id']; ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['description']; ?></td>
			<td><?php echo $row['price']; ?></td>
			<td>
				<a href="view.php?view=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-eye-open"></span> View</a>
				<a href="edit.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-edit"></span> Edit</a>
				<a href="productssession.php?del=<?php echo $row['id']; ?>"class="btn btn-sm btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>
    </div> <!-- end .container -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</script>
</body>
</html>
