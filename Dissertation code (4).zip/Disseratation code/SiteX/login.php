<?php
    if(isset($_GET['loginFailed'])){
      $out = "The username or password you entered is incorrect.";
      echo "<script type='text/javascript'>alert('$out');</script>";
    }

//include_once ('track.php');
// core configuration
//include_once "config.php";
// set page title
$page_title="Login";
// include page header HTML
include_once 'loginhead.php';
// footer HTML and JavaScript codes
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="author" content="SitePoint">
  <link rel="stylesheet" href="customer.css">
</head>
<body>

<?php
    echo "<div class='col-sm-6 col-md-4 col-md-offset-4'>";

        // alert messages will be here

        // actual HTML login form
        echo "<div class='account-wall'>";
            echo "<div id='my-tab-content' class='tab-content'>";
                echo "<div class='tab-pane active' id='login'>";
                    echo "<img class='profile-img' src='login_icon.png'>";
                    echo "<form action='config.php' class='form-signin' method='post'>";
                        echo "<input type='text' name='username' class='form-control' placeholder='Username' required autofocus />";
                        echo "<input type='password' name='password' class='form-control' placeholder='Password' required />";
                        echo "<input type='submit' class='btn btn-lg btn-primary btn-block' value='Log In' />";
                    echo "</form>";
                echo "</div>";
            echo "</div>";
        echo "</div>";

    echo "</div>";

    // footer HTML and JavaScript codes
    include_once "footer.php";
?>
</body>
</html>
