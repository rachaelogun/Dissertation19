<?php
// core configuration
include_once "config.php";
// set page title
$page_title="Order Details";
// include page header HTML
include_once 'header.php';
//session_start();
$connect = mysqli_connect("localhost", "root", "", "login_system");

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			array_push($_SESSION['shopping_cart'], $item_array);
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>window.location="homepage.php"</script>';
			}
		}
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "clear")
	{
    foreach($_SESSION["shopping_cart"] as $keys => $values)
    		{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>window.location="homepage.php"</script>';
			}
		}
	}


			$username=$_SESSION["username"];//session id of the current user
			$query= mysqli_query($connection, "SELECT name, lname, username, country, number, address FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id

			// to display the row of the database as string not as resource id, we must use functions such as mysql_fetch_assoc() or mysql_fetch_row(). They have return type of array
			$row = @mysqli_fetch_array($query);
			$name=$row[0]; // echo $row[0] displays fname.
	    $lname=$row[1]; // echo $row[0] displays fname.
	    $username=$row[2]; // echo $row[0] displays fname.
	    $country=$row[3]; // echo $row[0] displays fname.
	    $number=$row[4]; // echo $row[0] displays fname.
	    $address=$row[5]; // echo $row[0] displays fname.


		?>
	<head>
		<title>Welcome <?php echo $name;?></title>
	  <title>Welcome <?php echo $lname;?></title>
	  <title>Welcome <?php echo $username;?></title>
	  <title>Welcome <?php echo $country;?></title>
	  <title>Welcome <?php echo $number;?></title>
	  <title>Welcome <?php echo $address;?></title>
	</head>

	<body>
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="jumbotron">

				<link rel="stylesheet" type="text/css" href="check.css">


 <div class="d-flex">
   <form action="" method="">
     <label>
       <span class="fname">First Name <span class="required"></span></span>
			 <input type="text" name="idtest" value="<?php echo ($name); ?>" />
     </label>
     <label>
       <span class="lname">Last Name <span class="required">*</span></span>
			 <input type="text" name="idtest" value="<?php echo ($lname); ?>" />
     </label>
     <label>
       <span>Country <span class="required">*</span></span>
			 <input type="text" name="idtest" value="<?php echo ($country); ?>" />
     </label>
     <label>
       <span>Street Address <span class="required">*</span></span>
			 <input type="text" name="address" value="<?php echo ($address); ?>" />
     </label>
     <label>
     <label>
       <span>Phone <span class="required">*</span></span>
			 <input type="text" name="address" value="<?php echo ($number); ?>" />
     </label>
   </form>
   <div class="Yorder">
     <table>
       <tr>
         <th colspan="2">Your order</th>
       </tr>

<?php
if(!empty($_SESSION["shopping_cart"]))
{
	$total = 0;
	foreach($_SESSION["shopping_cart"] as $keys => $values)
	{
?>
<tr>
	<td><?php echo $values["item_name"]; ?></td>
		<td><?php echo $values["item_id"]; ?></td>
	<td><?php echo $values["item_quantity"]; ?></td>
	<td>£ <?php echo $values["item_price"]; ?></td>
</tr>
<?php
		$total = $total + ($values["item_quantity"] * $values["item_price"]);
	}
?>

<?php
}
?>
			 			<?php	 $num = 25;
			 		 $percentage = 20;
			 		 $num += $num*($percentage/100);
			 		 $num = round($num, 1);      // 4
			 		 $num = sprintf('%0.2f', $num);
					 $total += $num;
			 				?>
       <tr>
         <td>Shipping</td>
         <td>£<?php echo $num;?></td>
       </tr>
			 <td>Total Price</td>
			 <td>£<?php echo $total;?></td>
			</tr>
		</table>
		 <tr><td style='width:50%;' class='text-align-center'>
	 		<div class='btn-group' data-toggle='buttons'>
					<div>
      <input type="radio" name="dbt" value="cd"> Cash on Delivery
    </div>
    <div>
      <input type="radio" name="dbt" value="cd"> Bank Transfer <span>
      </span>
    </div>
			<p>
				Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.
		</p>
			<!--<di<!--v class='text-align-center'><a href='place_order.php?action=clear' class='btn btn-lg btn-success btn-cash-on-delivery'><span class='glyphicon glyphicon-shopping-cart'></span> Place Order</a>
			-->	<div class='text-align-center'><a href='process.php' class='btn btn-lg btn-success btn-cash-on-delivery'><span class='glyphicon glyphicon-shopping-cart'></span> Place Order</a>
</div>
			</body>
    </html>
