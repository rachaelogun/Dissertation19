<?php
// core configuration

include_once "config.php";
// set page title
$page_title="Order Confirmation";
// include page header HTML
include_once 'header.php';

//session_start();
$connect = mysqli_connect("localhost", "root", "", "login_system");



if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			array_push($_SESSION['shopping_cart'], $item_array);
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}



if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>window.location="cart.php"</script>';
			}
		}
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "clear")
	{
    foreach($_SESSION["shopping_cart"] as $keys => $values)
    		{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>window.location="place_order.php"</script>';
			}
		}
	}
?>

<h3>Your Order has been processed.</h3>
   <!-- Bootstrap CSS -->
 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" media="screen">


 <!-- blueimp & blue imp gallery CSS -->
 <link rel="stylesheet" href="https://www.codeofaninja.com/demos/shopping-cart-in-php-mysql-complete/libs/js/Bootstrap-Image-Gallery-3.1.1/css/blueimp-gallery.min.css">
 <link rel="stylesheet" href="https://www.codeofaninja.com/demos/shopping-cart-in-php-mysql-complete/libs/js/Bootstrap-Image-Gallery-3.1.1/css/bootstrap-image-gallery.min.css">
