<?php
session_start();
//entry.php
require ('connect_db.php');

// set page title
$page_title="Customer";
// include page header HTML
include_once 'header.php';

$sql = 'SELECT * FROM forum';
$result = mysqli_query($connection, $sql);
if (mysqli_num_rows($result) > 0)
{
// Statements to be inserted here (step 6).
}
else
{
echo '<p>There are currently no messages.</p>';
}
echo '<table><tr><th><h3>Posted By</th></h3>';
echo "</table>";
while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC) )
{

  echo "<div class='comment-box'><p>";
echo $row['username']."<br>";
 echo $row['date']."<br>";
 echo nl2br ($row['message']);
 echo "</p></div>";

}

mysqli_close($connection);

?>

<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Forum</title>
  <link rel="stylesheet" type="text/css" href="comment.css">
</head>
