<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'login_system');

	// initialize variables
	$customer_id = "";
	$user_url= "";
  $total= "";
	$date = "";
	$order_id = 0;
	$update = false;

if (isset($_GET['del'])) {
	$order_id = $_GET['del'];
	mysqli_query($db, "DELETE FROM orders WHERE order_id = $order_id");
	$_SESSION['message'] = "User deleted!";
	header('location: location.php');
}

	$results = mysqli_query($db, "SELECT * FROM orders");
?>
