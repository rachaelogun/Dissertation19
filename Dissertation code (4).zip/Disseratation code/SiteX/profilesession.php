<?php

require('config.php');

// initialize variables
$name = "";
$lname = "";
$address = "";
$country = "";
$number = "";
$id = 0;
$update = false;

if (isset($_POST['update'])) {
	$id = $_POST['id'];
	$name = $_POST['name'];
	$lname = $_POST['lname'];
	$address = $_POST['address'];
  $country = $_POST['country'];
  $number = $_POST['number'];

	mysqli_query($connection, "UPDATE users SET name='$name', lname='$lname', address='$address', country='$country', number='$number' WHERE id=$id");
	$_SESSION['message'] = "Profile Updated!";
	header('location: profile.php');
}

if (isset($_GET['del'])) {
$id = $_GET['del'];
mysqli_query($connection, "DELETE FROM users WHERE id=$id");
$_SESSION['message'] = "profile deleted!";
header('location: create.php');
}

$results = mysqli_query($connection, "SELECT * FROM users");


	?>
