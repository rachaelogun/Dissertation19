<?Php
if(!isset($_SESSION['username'])){
  echo "<script type='text/javascript'>alert('Hello Attacker, you can not access this account. ')
 window.location.href = '../SiteX/login.php?loginfailed';
 </script>";}

exit;

}

?>
