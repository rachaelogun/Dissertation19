<?php
session_start();
include_once "config.php";

// set page title
$page_title="Login";
// include page header HTML
include_once 'loginhead.php';
// footer HTML and JavaScript codes
$userToken = bin2hex(openssl_random_pseudo_bytes(24));

//assign the token to a session variable.
$_SESSION['user_token'] = $userToken;

$_SESSION['last_login_date'] = time();

	//check if can login again
  if(isset($_SESSION['attempt_again'])){
    $now = time();
    if($now >= $_SESSION['attempt_again']){
      unset($_SESSION['attempt']);
      unset($_SESSION['attempt_again']);
    }
  }

  //set disable if three login attempts has been made
  $disable = '';
  if(isset($_SESSION['attempt']) && $_SESSION['attempt'] >= 3){
    $disable = 'disabled';
  }
?>

      <?php   if(isset($_SESSION['error'])){
              ?>
              <div id="message">
          <div style="padding: 2px;">
              <div id="inner-message" class="alert alert-danger text-center">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                  <?php echo $_SESSION['error']; ?>
              </div>
          </div>
      </div>
      <?php
      unset($_SESSION['error']);
    }

      if(isset($_SESSION['success'])){
        ?>
        <div id="message">
    <div style="padding: 2px;">
        <div id="inner-message" class="alert alert-sucess text-center">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <?php echo $_SESSION['success']; ?>
        </div>
        </div>
        </div>
        <?php
        unset($_SESSION['success']);
      }
 ?>
 <?php header("Content-Type: text/html; charset=utf-8"); ?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="author" content="SitePoint">
  <link rel="stylesheet" href="customer.css">
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>

<?php
    echo "<div class='col-sm-6 col-md-4 col-md-offset-4'>";
        // actual HTML login form
        echo "<div class='account-wall'>";
            echo "<div id='my-tab-content' class='tab-content'>";
                echo "<div class='tab-pane active' id='login'>";
                    echo "<img class='profile-img' src='login_icon.png'>";
                    echo "<form method='post' class='form-signin'>";
                  //  echo "<input type = 'hidden' name = 'hidden' value = '".$atmp."'>";
                  (!empty($userror)) ?  : '';
                        echo "<input type='text' name='username' id='password' class='form-control' placeholder='Username' required autofocus />";
                        echo "<span class='help-block'> $userror</span>";
                        (!empty($password_err)) ?  : '';
                        echo "<input type='password' name='password' id='password' class='form-control' placeholder='Password' required />";
                        echo "<span class='help-block'> $passworderror</span>";
                        echo "<div class='g-recaptcha' data-sitekey='6Leep5oUAAAAAPK3QPZG901-pcRISi72YZ_Yqud8'></div>";
                        echo "<input id = 'myButton' type='submit' name='login'  $disable value='Login' class='btn btn-lg btn-primary btn-block' />";
                      //echo "<button type='submit' name='login' class="btn btn-primary" <?php echo $disable;
                      echo "<input type = 'hidden' name = 'recaptcha' value = 'TRUE'>";
                    echo "</form>";
                echo "</div>";
            echo "</div>";
        echo "</div>";

    echo "</div>";
    // footer HTML and JavaScript codes
?>

</body>

<?php include_once "footer.php";
?>

</html>
