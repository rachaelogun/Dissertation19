 <?php
 // Include config file
 require_once 'conn.php';

 // Define variables and initialize with empty values
 $username = $password = $name = $lname = $address = $country = $number = $captcha = "";
 $usernamerror = $passworderror = $namerror = $lnamerror = $addresserror = $countryerror = $numberror = $captchaerror = "";

 // Processing form data when form is submitted
 if($_SERVER["REQUEST_METHOD"] == "POST"){

     // Validate user information

     if(empty(trim($_POST["name"]))){
         $namerror = "Please enter a name.";
     }else{
         $name = trim($_POST['name']);
     }
     if(empty(trim($_POST["lname"]))){
         $lnamerror = "Please enter a last name.";
     }else{
         $lname = trim($_POST['lname']);
     }
     if(empty(trim($_POST["address"]))){
         $addresserror = "Please enter a address.";
     }else{
         $address = trim($_POST['address']);
     }
     if(empty(trim($_POST["country"]))){
         $countryerror = "Please enter a country.";
     }else{
         $country = trim($_POST['country']);
     }
     if(empty(trim($_POST["number"]))){
         $numberror = "Please enter a number.";
     }else{
         $number = trim($_POST['number']);
     }
     if(isset($_POST['g-recaptcha-response'])){
       $captcha=$_POST['g-recaptcha-response'];
     }
     if(!$captcha){
       echo "<script type='text/javascript'>alert('Please complete the recaptcha form.')
      window.location.href = 'register.php?failedregistration';
      </script>";
     }
     $secretKey = "6LcwhZ0UAAAAAGvtZDZgmk9npGPgmNkoRfSr8Vba";
     $ip = $_SERVER['REMOTE_ADDR'];
     // post request to server
     $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
     $response = file_get_contents($url);
     $responseKeys = json_decode($response,true);
     // this is used to return JSON with success as true before it continues to run the if statements

     if(empty(trim($_POST["username"]))){
         $usernamerror = "Please enter a username.";
     }
     else{
         // Prepare a select statement
         $sql = "SELECT id FROM users WHERE username = ?";

         if($stmt = mysqli_prepare($connection, $sql)){
             // Bind variables to the prepared statement as parameters
             mysqli_stmt_bind_param($stmt, "s", $param_username);

             // Set parameters
             $param_username = trim($_POST["username"]);

             // Attempt to execute the prepared statement
             if(mysqli_stmt_execute($stmt)){
                 /* store result */
                 mysqli_stmt_store_result($stmt);

                 if(mysqli_stmt_num_rows($stmt) == 1){
                     $usernamerror = "This username is already in use, Try another one.";
                 } else{
                     $username = trim($_POST["username"]);
                 }
             } else{
                 echo "An error has occured, Please try again later.";
             }
         }

         // Close statement
         mysqli_stmt_close($stmt);
     }

     // Validate password
     if(empty(trim($_POST['password']))){
         $passworderror = "Enter user password.";
     } elseif(strlen(trim($_POST['password'])) < 6){
         $passworderror = "Password must contain 6 characters.";
     } else{
         $password = trim($_POST['password']);
     }

     // Check input errors before inserting in database
     if(empty($usernamerror) && empty($passworderror)){
       if($responseKeys["success"]) {

         // Prepare an insert statement
         $sql = "INSERT INTO users (username, password, name, lname, country, address, number) VALUES (?, ?, ?, ?, ?, ?, ?)";

         if($stmt = mysqli_prepare($connection, $sql)){
             // Bind variables to the prepared statement as parameters
             mysqli_stmt_bind_param($stmt, "sssssss", $param_username, $param_password, $param_name, $param_lname, $param_country, $param_address, $param_number);

             // Set parameters
             $param_username = $username;
             $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
             $param_name = $name;
             $param_lname = $lname;
             $param_country = $country;
             $param_address = $address;
             $param_number = $number;

             // Attempt to execute the prepared statement
             if(mysqli_stmt_execute($stmt)){

//if recaptcha is succefully done regiter the user
                 // Redirect to login page
                 echo "<script type='text/javascript'>alert('Registered Successfully')
                          window.location.href = 'login.php' </script>";
                        }
}
}
                                     else{

                 echo "Something went wrong. Please try again later.";
             }


         // Close statement
         mysqli_stmt_close($stmt);
     }

     // Close connection
     mysqli_close($connection);
 }
 ?>
