<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'login_system');

	// initialize variables
	$username = "";
	$address = "";
	$name = "";
	$contact = "";
	$access_level = "";
	$id = 0;
	$update = false;

	if (isset($_POST['save'])) {
		$username = $_POST['username'];
		$address = $_POST['address'];
		$name = $_POST['name'];
		$contact = $_POST['contact'];
		$access_level = $_POST['access_level'];

		mysqli_query($db, "INSERT INTO users (username, address, access_level) VALUES ('$username', '$address','$name', '$contact', '$access_level')");
		$_SESSION['message'] = "User saved!";
		header('location: createusers.php');
	}

	if (isset($_POST['update'])) {
		$id = $_POST['id'];
		$username = $_POST['username'];
		$address = $_POST['address'];
		$name = $_POST['name'];
		$contact = $_POST['contact'];
		$access_level = $_POST['access_level'];

		mysqli_query($db, "UPDATE users SET username='$username', address='$address', name='$name', contact='$contact',  access_level='$access_level' WHERE id=$id");
		$_SESSION['message'] = "User updated!";
		header('location: users.php');
	}

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM users WHERE id=$id");
	$_SESSION['message'] = "User deleted!";
	header('location: users.php');
}

	$results = mysqli_query($db, "SELECT * FROM users");
?>


<?php
// core configuration
	if (isset($_GET['view'])) {
		$id = $_GET['view'];
		$record = mysqli_query($db, "SELECT * FROM users WHERE id=$id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$username = $n['username'];
			$address = $n['address'];
      $access_level = $n['access_level'];
		}
	}

?>

<!DOCTYPE HTML>
<html>
<head>
    <title>PDO - Read One Record - PHP CRUD Tutorial</title>

    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

</head>
<body>
    <!-- container -->
    <div class="container">
        <div class="page-header">
            <h1>Read Product</h1>
        </div>

        <?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>
<?php $results = mysqli_query($db, "SELECT * FROM users"); ?>
	<?php while ($row = mysqli_fetch_array($results)) { ?>
	<?php } ?>


        <!--we have our html table here where the record will be displayed-->
        <table class='table table-hover table-responsive table-bordered'>
          <form method="post" action="usersession.php" >
            <input type="hidden" username="id" value="<?php echo $id; ?>">
            <tr>
                <td>Username</td>
                <td><?php echo $username; ?></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><?php echo $address; ?></td>
            </tr>
            <tr>
                <td>Access Level</td>
                <td><?php echo $access_level; ?></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <a href='users.php' class='btn btn-danger'>Back to read users</a>
                </td>
            </tr>
        </table>
    </div> <!-- end .container -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>
