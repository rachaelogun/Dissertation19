<?php
require_once "conn.php";
if(!isset($_SESSION)){
}
//session_start();
$username = $password = $captcha = "";
$userror = $passworderror = "";


if(isset($_SESSION["username"]))
{
}

if($_SERVER["REQUEST_METHOD"] == "POST"){

  if(empty(trim($_POST["username"]))){
       $username_err = 'Both Fields are required.';
   } else{
       $username = trim($_POST["username"]);
   }
   if(!isset($_SESSION['attempt'])){
     $_SESSION['attempt'] = 1;
   }
  if(empty(trim($_POST['password']))){
      $passworderror = 'Both Fields are required.';
  } else{
      $password = trim($_POST['password']);
  }

   if(isset($_POST['g-recaptcha-response'])){
     $captcha=$_POST['g-recaptcha-response'];
   }
   if(!$captcha){
     echo "<script type='text/javascript'>alert('Please complete the recaptcha form.')
    window.location.href = 'login.php?failedlogin';
    </script>";
   }

   $secretKey = "6Leep5oUAAAAAMzNpiOh2AbwRJABvysro-5U-sEV";
   $ip = $_SERVER['REMOTE_ADDR'];
   // post request to server
   $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
   $response = file_get_contents($url);
   $responseKeys = json_decode($response,true);
   // this is used to return JSON with success as true before it continues to run the if statements

     if(empty($userror) && empty($passworderror)){
       $username = mysqli_real_escape_string($connection, $_POST["username"]);
       $password = mysqli_real_escape_string($connection, $_POST["password"]);
       // Prepare a select statement

       $fakequery = "SELECT * FROM users WHERE username = ?";
       $result = mysqli_query($connection, $fakequery);
       $sql_id = "SELECT MAX(id) FROM failed_login";
       //$query_id = $connection -> query($sql_id);
       $query_id = mysqli_query($connection, $sql_id);
       $row = @mysqli_fetch_assoc($query_id);
       //$row = $query_id -> fetch_assoc();
       $id = $row["MAX(id)"] + 1;
       $change_id = "ALTER TABLE failed_login AUTO_INCREMENT=".$id;
       mysqli_query($connection, $change_id);
       $IP = $_SERVER['REMOTE_ADDR'];
       $user_url = $_SERVER["PHP_SELF"];
       // you need to change this query into your style by inserting the values we discovered in the previous query
       $fakesql = "INSERT INTO failed_login (id, user_url, IP, username, date) VALUES ('$id', '$user_url', '$IP','$username', CURRENT_TIMESTAMP)";
       //$sql = $connection -> query($sql);
       mysqli_query($connection, $fakesql);

//sql query below for the table users to confirm the username is inside the db
       $sql = "SELECT username, password FROM users WHERE username = ?";

   if($stmt = mysqli_prepare($connection, $sql)){
       // Bind variables to the prepared statement as parameters
       mysqli_stmt_bind_param($stmt, "s", $param_username);

       // Set parameters
       $param_username = $username;

       // Attempt to execute the prepared statement
       if(mysqli_stmt_execute($stmt)){
           // Store result
           mysqli_stmt_store_result($stmt);

           // Check if username exists, if yes then verify password
           if(mysqli_stmt_num_rows($stmt) == 1){
               // Bind result variables
               mysqli_stmt_bind_result($stmt, $username, $hashed_password);
               if(mysqli_stmt_fetch($stmt)){
                   if(password_verify($password, $hashed_password)){
                   //  if($response['success'] == false)
                   //if($responseKeys["success"]) {

                       /* Password is correct, so start a new session and
                       save the username to the session */

                       if($responseKeys["success"]) {
                         $_SESSION['LAST_ACTIVITY'] = time();
                         $userToken = bin2hex(openssl_random_pseudo_bytes(24));

//assign the token to a session variable.
$_SESSION['user_token'] = $userToken;
                       $_SESSION["username"] = $username;
                       header("location:homepage.php?loginsuccessful");
                       $_SESSION['success'] = 'Login successful';
                       unset($_SESSION['attempt']);
                     }
                   }

                 else
                 {
                   echo "<script type='text/javascript'>alert('The username or password you entered is incorrect, number of attempts is ".$_SESSION['attempt']."')
                  window.location.href = 'login.php?loginfailed';
                  </script>";

                      $_SESSION['error'] = 'Incorrect User information provided';
                      //this is where we put our 3 attempt limit
                      $_SESSION['attempt'] += 1;
                      //set the time to allow login if third attempt is reach
                      if($_SESSION['attempt'] == 3){
                        $_SESSION['attempt_again'] = time() + (1*60);
                      }
                      $passworderror = 'The password you entered was not valid.';
}
}
}
                else{

            $_SESSION['error'] = 'No account with that username';
}
          }
              }
           else{
        $_SESSION['error'] = 'No account with that username';
          echo "Something went wrong. Please try again later.";


    }
    if ($username = "admin"){

      //sql query below for the table users to confirm the username is inside the db
             $sql = "SELECT username, password FROM admin_y WHERE username = ?";

         if($stmt = mysqli_prepare($connection, $sql)){
             // Bind variables to the prepared statement as parameters
             mysqli_stmt_bind_param($stmt, "s", $param_username);

             // Set parameters
             $param_username = $username;

             // Attempt to execute the prepared statement
             if(mysqli_stmt_execute($stmt)){
                 // Store result
                 mysqli_stmt_store_result($stmt);

                 // Check if username exists, if yes then verify password
                 if(mysqli_stmt_num_rows($stmt) == 1){
                     // Bind result variables
                     mysqli_stmt_bind_result($stmt, $username, $hashed_password);
                     if(mysqli_stmt_fetch($stmt)){
                         if(password_verify($password, $hashed_password)){
                         //  if($response['success'] == false)
                         //if($responseKeys["success"]) {
                             /* Password is correct, so start a new session and
                             save the username to the session */
                             if($responseKeys["success"]) {
                               $_SESSION['LAST_ACTIVITY'] = time();
                             $_SESSION["username"] = $username;
                             header("location:admindex.php?loginsuccessful");
                             $_SESSION['success'] = 'Login successful';
                             unset($_SESSION['attempt']);
                           }
                         }

                       else
                       {
                         echo "<script type='text/javascript'>alert('The username or password you entered is incorrect, number of attempts is ".$_SESSION['attempt']."')
                        window.location.href = 'login.php?loginfailed';
                        </script>";

                            $_SESSION['error'] = 'Incorrect User information provided';
                            //this is where we put our 3 attempt limit
                            $_SESSION['attempt'] += 1;
                            //set the time to allow login if third attempt is reach
                            if($_SESSION['attempt'] == 3){
                              $_SESSION['attempt_again'] = time() + (1*60);
                            }
                            $passworderror = 'The password you entered was not valid.';
      }
      }
      }
                      else{

                  $_SESSION['error'] = 'No account with that username';
      }
                }
                    }
                 else{
              $_SESSION['error'] = 'No account with that username';
                echo "Something went wrong. Please try again later.";



    }
  }

  // Close statement
 mysqli_stmt_close($stmt);
}
  mysqli_close($connection);
}
