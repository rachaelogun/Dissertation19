<?php
// core configuration
include_once "config.php";
// set page title
$page_title="Profile";
// include page header HTML
include_once 'header.php';
//session_start();
$connection = mysqli_connect("localhost", "root", "", "login_system");

			$username=$_SESSION["username"];//session id of the current user
			$query= mysqli_query($connection, "SELECT name, lname, username, country, number, address FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id

			// to display the row of the database as string not as resource id, we must use functions such as mysql_fetch_assoc() or mysql_fetch_row(). They have return type of array
			$row = @mysqli_fetch_array($query);
			$name=$row[0]; // echo $row[0] displays fname.
	    $lname=$row[1]; // echo $row[0] displays fname.
	    $username=$row[2]; // echo $row[0] displays fname.
	    $country=$row[3]; // echo $row[0] displays fname.
	    $number=$row[4]; // echo $row[0] displays fname.
	    $address=$row[5]; // echo $row[0] displays fname.

		?>
	<head>
		<title>Welcome <?php echo $name;?></title>
	  <title>Welcome <?php echo $lname;?></title>
	  <title>Welcome <?php echo $username;?></title>
	  <title>Welcome <?php echo $country;?></title>
	  <title>Welcome <?php echo $number;?></title>
	  <title>Welcome <?php echo $address;?></title>
	</head>

	<body>
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="jumbotron">

				<link rel="stylesheet" type="text/css" href="check.css">


 <div class="d-flex">
     <form action="change.php" method="post">

     <label>
       <span class="fname">First Name <span class="required"></span></span>
			 <input type="text" name="idtest" value="<?php echo ($name); ?>" />
     </label>
     <label>
       <span class="lname">Last Name <span class="required">*</span></span>
			 <input type="text" name="idtest" value="<?php echo ($lname); ?>" />
     </label>
     <label>
       <span>Country <span class="required">*</span></span>
			 <input type="text" name="idtest" value="<?php echo ($country); ?>" />
     </label>
     <label>
       <span>Street Address <span class="required">*</span></span>
			 <input type="text" name="address" value="<?php echo ($address); ?>" />
     </label>
     <label>
     <label>
       <span>Phone <span class="required">*</span></span>
			 <input type="text" name="address" value="<?php echo ($number); ?>" />
     </label>
		 <input type = "submit" value = "update">
		 <input type = "hidden" name = "submitted" value = "TRUE">
   </form>
