<?php
// core configuration
include ('db.php');

session_start();
if ($connection = mysqli_connect(dbhost, dbuser, dbpass)){
	//the connection information holding the hostname, username and password of the database been accessed

	//Handles the errors that occurs
		if(!mysqli_select_db($connection, dbname)){
			//check that the database can be accessed
			die("Database couldn't be used. Try again!!".mysqli_connect_error($connection));
			//if not connection dies and user needs try again.
			exit();
		}
		else
		{
			if(!$connection->set_charset("utf-8")){
				//if the connection isnt correct
				$result = "error loading utf-8";
				//error message displayed
			}
			else
			{
				//else utf8 will be set
				$result = " utf-8 set";
			}
		}
	}
	else
	{
		//connection error to MySQL
		die("Unable to connect to MySQL, Try again!!".mysqli_connect_error($connection));
		exit();
	}

// set page title
$page_title="Customer";
// include page header HTML
include_once 'header.php';
echo "<div class='col-md-12'>";
          echo "<div class='alert alert'>";
            echo "<strong>Hi " . $_SESSION['username'] . ", welcome back!</strong>";
        echo "</div>";
echo "</div>";

$_SESSION['LAST_ACTIVITY'] = time();
if(isset($_SESSION['loggedIn'])){
    $username = $_SESSION['username'];
}
if (isset($_GET['view'])) {
  $id = $_GET['view'];
  $record = mysqli_query($connection, "SELECT * FROM users WHERE id=$id");

  if (@count($record) == 1 ) {
    $n = @mysqli_fetch_array($record);
    $username = $n['username'];

  }
}
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$update = true;
	$record = mysqli_query($connection, "SELECT * FROM users WHERE id=$id");

	if (@count($record) == 1 ) {
		$n = @mysqli_fetch_array($record);
		$name = $n['name'];
		$lname = $n['lname'];
		$address = $n['address'];
		$country = $n['country'];
		$number = $n['number'];
	}

}

?>

<?php header("Content-Type: text/html; charset=utf-8"); ?>

<!DOCTYPE html>
<html>
<head>
	<title> Update Profile</title>
</head>
<body>
	<?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>

<?php
	$username=$_SESSION["username"];//session id of the current user
	$query= mysqli_query($connection, "SELECT * FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id
 ?>


	<?php while (	$row = mysqli_fetch_assoc($query));
{
	$name = $row['name'];
$lname = $row['lname'];
$number = $row['number'];
$address = $row['address'];
$country = $row['country'];
$username = $row['username'];
	?>
	<?php

  //include_once('connection.php'); //For connecting the database

    $username=$_SESSION["username"];//session id of the current user
    $query= mysqli_query($connection, "SELECT * FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id

    // to display the row of the database as string not as resource id, we must use functions such as mysql_fetch_assoc() or mysql_fetch_row(). They have return type of array
    $row = mysqli_fetch_assoc($query);
?>
<html>
 <body>
 <div class="container">
	 <div class="row">
		 <div class="col-sm-12">
			 <div class="jumbotron">
				 <link rel="stylesheet" type="text/css" href="check.css">
				 <div class="d-flex">
				 	 <form action="" method="post">
				 		<label>
				 			<span class="fname">First Name <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo $row['name']; ?>" />
				 		</label>
				 		<label>
				 			<span class="lname">Last Name <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo $row['lname']; ?>" />
				 		</label>
				 		<label>
				 			<span class="address">Address <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo htmlspecialchars(ucfirst($address), ENT_NOQUOTES, "UTF-8"); ?>" />
				 		</label>
				 		<label>
				 			<span class="country">Country <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo htmlspecialchars(ucfirst($country), ENT_NOQUOTES, "UTF-8"); ?>" />
				 		</label>
				 		<label>
				 			<span class="number">Phone Number <span class="required"></span></span>
				 			<input type="text" name="idtest" value="<?php echo htmlspecialchars(ucfirst($number), ENT_NOQUOTES, "UTF-8"); ?>" />
				 		</label>

				 <div align = "right">
				 	<a href='userprofile.php?edit=<?php echo $row['id']; ?>' class="btn btn-default";><span class="glyphicon glyphicon-edit"></span> Edit User Profile</a>
				 </div>
				 	<?php } ?>
				 </form>

				 </body>
				 </html>
