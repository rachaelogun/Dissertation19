
  <?php
  //session_start();
  include("config.php");
  // username and password sent from form
  $connection = mysqli_connect("localhost", "root", "", "login_system");
  $username=$_SESSION["username"];//session id of the current user
  $query= mysqli_query($connection, "SELECT name, lname, username, country, number, address FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id

  // to display the row of the database as string not as resource id, we must use functions such as mysql_fetch_assoc() or mysql_fetch_row(). They have return type of array
  $row = @mysqli_fetch_array($query);
  $name=$row[0]; // echo $row[0] displays fname.
  $lname=$row[1]; // echo $row[0] displays fname.
  $username=$row[2]; // echo $row[0] displays fname.
  $country=$row[3]; // echo $row[0] displays fname.
  $number=$row[4]; // echo $row[0] displays fname.
  $address=$row[5]; // echo $row[0] displays fname.
  $userid=0;
  $useridsql = "SELECT id FROM users WHERE username = '$username'";
  $query_id = mysqli_query($connection, $useridsql);
  $result = mysqli_num_rows($query_id);

  //$query_id = $connection -> mysqli_query($useridsql);
  if ($result == 1){
  //if($query_id -> num_rows > 0){
    while($row = mysqli_fetch_assoc($query_id)){
      $userid = $row['id'];
    }
  }
  $checkformembers = mysqli_query($connection, "SELECT * FROM name, address WHERE username = '$username'");
  if(@mysqli_num_rows($checkformembers, $connection) != 0){
  header("location:sign_up_usererror.php");
  die();
  }
  $result = mysqli_query($connection, "UPDATE name, address SET username = '$username'");
  if($result) {
  $_SESSION['username'] = $_POST['username'];
  header("location:ses.php");
  die();
  }
  ?>
