<?php
$page_title = 'PHP Process Error';
// core configuration
include ('db.php');

session_start();
if ($connection = mysqli_connect(dbhost, dbuser, dbpass)){
	//the connection information holding the hostname, username and password of the database been accessed

	//Handles the errors that occurs
		if(!mysqli_select_db($connection, dbname)){
			//check that the database can be accessed
			die("Database couldn't be used. Try again!!".mysqli_connect_error($connection));
			//if not connection dies and user needs try again.
			exit();
		}
		else
		{
			if(!$connection->set_charset("utf-8")){
				//if the connection isnt correct
				$result = "error loading utf-8";
				//error message displayed
			}
			else
			{
				//else utf8 will be set
				$result = " utf-8 set";
			}
		}
	}
	else
	{
		//connection error to MySQL
		die("Unable to connect to MySQL, Try again!!".mysqli_connect_error($connection));
		exit();
	}


function fail($str)
{
echo "<p>Please enter a $str.</p>";
echo "<p><a href='post.php'>Post Message</a>";
exit();
}

if(isset($_POST['message']))
{
}
if (!empty(trim( $_POST['message'] ) ) )
{
  $clean_message = strip_tags($_POST['message']);
  $message = htmlentities (trim ($_POST['message']), ENT_NOQUOTES );
}
else {
  fail('message') ;
}
$username = $_SESSION['username'];

$userid=0;
$useridsql = "SELECT id FROM users WHERE username = '$username'";
$query_id = mysqli_query($connection, $useridsql);
$result = mysqli_num_rows($query_id);

if ($result == 1){
//if($query_id -> num_rows > 0){
  while($row = mysqli_fetch_assoc($query_id)){
    $userid = $row['id'];
  }
}

echo $userid;

$sql_id = "SELECT MAX(post_id) FROM forum";
//$query_id = $connection -> query($sql_id);
$query_id = mysqli_query($connection, $sql_id);
$row = mysqli_fetch_assoc($query_id);
//$row = $query_id -> fetch_assoc();
$post_id = $row["MAX(post_id)"] + 1;
$change_id = "ALTER TABLE forum AUTO_INCREMENT=".$post_id;
mysqli_query($connection, $change_id);
//$connection->query($change_id);,
$username = $username;


$sql = "INSERT INTO forum (post_id, testid, username, message, date) VALUES
(?, ?, ?, ?, current_time)";

if($stmt = mysqli_prepare($connection, $sql)){
    // Bind variables to the prepared statement as parameters
    mysqli_stmt_bind_param($stmt, "ssss", $param_post_id, $param_testid, $param_username, $param_message);

    // Set parameters
    $param_username = $username;
    $param_post_id = $postid;
    $param_testid = $userid;
    $param_message = $message;

    // Attempt to execute the prepared statement
    if(mysqli_stmt_execute($stmt)){

//$result = mysqli_query ($connection, $sql);
//if ( mysqli_affected_rows( $connection ) != 1 )
//{
//echo '<p>Error</p>'.mysqli_error( $connection ) ;
//mysqli_close($connection);
//}
//else
//{
mysqli_close($connection);
header('Location: forum.php');
}
}
else{
echo "<script type='text/javascript'>alert('Unable to comment, Please try again later.')
         window.location.href = 'forum.php' </script>";
}
