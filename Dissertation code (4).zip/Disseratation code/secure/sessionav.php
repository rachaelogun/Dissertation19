<!-- navbar -->
<link rel="stylesheet" type="text/css" href="nav.css">
<div class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container-fluid">

        <div class="navbar-header">
            <!-- to enable navigation dropdown when viewed in mobile device -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <?php echo'<img src="l.png" alt="logoPlaceholder" height="95" width="300">'?>
      </div>

      <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">

              <!-- highlight for order related pages -->
              <li >
                  <a href="">Home</a>
              </li>

              <!-- highlight for user related pages -->
              <li <?php
                      echo $page_title=="About Us" ? "class='active'" : ""; ?> >
                  <a href="">About Us</a>
              </li>

							<li>
									<a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
										<i class="fa fa-caret-down"></i>
											Products <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
											</a>
											<ul class="dropdown-menu" role="menu">
												<li><a href="">Products</a></li>
												<li><a href="">Accessories</a></li>
											</ul>
										</a>
									</li>

                <li>
                  <a href="" >Cart
                    <span class="glyphicon glyphicon-shopping-cart" role="button" aria-expanded="false"></span>
                  </a>
                </li>
          </ul>

      </div><!--/.nav-collapse -->

  </div>
</div>
<!-- /navbar -->
