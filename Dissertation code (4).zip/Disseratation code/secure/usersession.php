<?php
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'login_system');

	// initialize variables
	$username = "";
	$address = "";
	$name = "";
	$contact = "";
	$access_level = "";
	$id = 0;
	$update = false;

	if (isset($_POST['save'])) {
		$username = $_POST['username'];
		$address = $_POST['address'];
		$name = $_POST['name'];
		$contact = $_POST['contact'];
		$access_level = $_POST['access_level'];

		mysqli_query($db, "INSERT INTO users (username, address, access_level) VALUES ('$username', '$address','$name', '$contact', '$access_level')");
		$_SESSION['message'] = "User saved!";
		header('location: createusers.php');
	}

	if (isset($_POST['update'])) {
		$id = $_POST['id'];
		$username = $_POST['username'];
		$address = $_POST['address'];
		$name = $_POST['name'];
		$contact = $_POST['contact'];
		$access_level = $_POST['access_level'];

		mysqli_query($db, "UPDATE users SET username='$username', address='$address', name='$name', contact='$contact',  access_level='$access_level' WHERE id=$id");
		$_SESSION['message'] = "User updated!";
		header('location: users.php');
	}

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM users WHERE id=$id");
	$_SESSION['message'] = "User deleted!";
	header('location: users.php');
}

	$results = mysqli_query($db, "SELECT * FROM users");
?>
