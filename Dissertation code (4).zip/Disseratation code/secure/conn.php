<?php
  require_once("db.php");

  if ($connection = mysqli_connect(dbhost, dbuser, dbpass)){
    //the connection information holding the hostname, username and password of the database been accessed

    //Handles the errors that occurs
      if(!mysqli_select_db($connection, dbname)){
        //check that the database can be accessed
        die("Database couldn't be used. Try again!!".mysqli_connect_error($connection));
        //if not connection dies and user needs try again.
        exit();
      }
      else
      {
        if(!$connection->set_charset("utf-8")){
          //if the connection isnt correct
          $result = "error loading utf-8";
          //error message displayed
        }
        else
        {
          //else utf8 will be set
          $result = " utf-8 set";
        }
      }
    }
    else
    {
      //connection error to MySQL
      die("Unable to connect to MySQL, Try again!!".mysqli_connect_error($connection));
      exit();
    }


// Set function to remove possible malicious input from attackers using any type of injection
function escape_input($insert){
  if (function_exists('mysqli_real_escape_string')) {
    global $connection;
    //set global using the connection information holding the hostname, username and password of the database been accessed.
    $insert = mysqli_real_escape_string($connection,trim($insert));
    $insert = strip_tags($insert);
  }
  else
  {
    $insert = mysqli_escape_string($connection, trim($insert));
    $insert = strip_tags($insert);
  }
  return $insert;
}
  ?>
