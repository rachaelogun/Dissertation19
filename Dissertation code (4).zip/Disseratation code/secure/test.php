
<?php
// core configuration
include ('db.php');

session_start();
if ($connection = mysqli_connect(dbhost, dbuser, dbpass)){
	//the connection information holding the hostname, username and password of the database been accessed

	//Handles the errors that occurs
		if(!mysqli_select_db($connection, dbname)){
			//check that the database can be accessed
			die("Database couldn't be used. Try again!!".mysqli_connect_error($connection));
			//if not connection dies and user needs try again.
			exit();
		}
		else
		{
			if(!$connection->set_charset("utf-8")){
				//if the connection isnt correct
				$result = "error loading utf-8";
				//error message displayed
			}
			else
			{
				//else utf8 will be set
				$result = " utf-8 set";
			}
		}
	}
	else
	{
		//connection error to MySQL
		die("Unable to connect to MySQL, Try again!!".mysqli_connect_error($connection));
		exit();
	}

  // set page title
  $page_title="Customer";
  // include page header HTML
  include_once 'header.php';
  echo "<div class='col-md-12'>";
            echo "<div class='alert alert'>";
              echo "<strong>Hi " . $_SESSION['username'] . ", welcome back!</strong>";
          echo "</div>";
  echo "</div>";

  $_SESSION['LAST_ACTIVITY'] = time();
  if(isset($_SESSION['loggedIn'])){
      $username = $_SESSION['username'];
  }





































  <?php

  // core configuration
  include ('db.php');

  session_start();
  if ($connection = mysqli_connect(dbhost, dbuser, dbpass)){
  	//the connection information holding the hostname, username and password of the database been accessed

  	//Handles the errors that occurs
  		if(!mysqli_select_db($connection, dbname)){
  			//check that the database can be accessed
  			die("Database couldn't be used. Try again!!".mysqli_connect_error($connection));
  			//if not connection dies and user needs try again.
  			exit();
  		}
  		else
  		{
  			if(!$connection->set_charset("utf-8")){
  				//if the connection isnt correct
  				$result = "error loading utf-8";
  				//error message displayed
  			}
  			else
  			{
  				//else utf8 will be set
  				$result = " utf-8 set";
  			}
  		}
  	}
  	else
  	{
  		//connection error to MySQL
  		die("Unable to connect to MySQL, Try again!!".mysqli_connect_error($connection));
  		exit();
  	}



  	function cleanInput($input) {

  	  $search = array(
  	    '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
  	    '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
  	    '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
  	    '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
  	  );

  	    $output = preg_replace($search, '', $input);
  	    return $output;
  	  }

  		function sanitize($input) {
  		    if (is_array($input)) {
  		        foreach($input as $var=>$val) {
  		            $output[$var] = sanitize($val);
  		        }
  		    }
  		    else {
  		        if (get_magic_quotes_gpc()) {
  		            $input = stripslashes($input);
  		        }
  		        $input  = cleanInput($input);
  		        $output = filter_var($input);
  		    }
  		    return $output;
  		}
  // initialize variablesg
  $name = "";
  $lname = "";
  $address = "";
  $country = "";
  $number = "";
  $id = 0;
  $update = false;

  if (isset($_POST['update'])) {
  	//$id = $_POST['id'];
  	$id = sanitize($_POST['id']);
  	$name = sanitize($_POST['name']);
  	$lname = sanitize($_POST['lname']);
  	$address = sanitize($_POST['address']);
  	$country = sanitize($_POST['country']);
  	$number = sanitize($_POST['number']);

  	if(preg_match ('%^[A-Za-z0-9\-\,\.\s\r\n]+$%', trim($_POST['address']))){

      $address_n = htmlspecialchars($_POST['address'], ENT_NOQUOTES, "UTF-8");

    } else {

      $address_n = FALSE;

    }


  	$validation_passed = false;

  	  if($id && $name && $lname && $address_n && $country && $number){
  	    $validation_passed = true;
  	  } else {
  	    $validation_passed = false;
  	  }

  	  $sql_upd = mysqli_query($connection, "UPDATE users SET name='$name', lname='$lname', address='$address', country='$country', number='$number' WHERE id=$id");
  	$_SESSION['message'] = "Profile Updated!";
  	header('location: profile.php');
  }
  if (isset($_GET['view'])) {
    $id = $_GET['view'];
    $record = "SELECT * FROM users WHERE id= ?";

    if (@count($record) == 1 ) {
      $n = @mysqli_fetch_array($record);
      $username = $n['username'];

    }
  }

  $results = mysqli_query($connection, "SELECT * FROM users");


  	?>
