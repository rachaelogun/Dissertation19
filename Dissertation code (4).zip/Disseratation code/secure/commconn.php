<?php
// core configuration
include_once "config.php";
// set page title
$page_title="Forum";
// include page header HTML
include_once 'header.php';
//session_start();
$connect = mysqli_connect("localhost", "root", "", "login_systemy");

$item_id =  0;
$quantity = 0;
$price = 0.0;

$total = 0.0;

// get the user id, i was able to use your style because i can reference by column such as $n['id'];
$username = $_SESSION['username'];

$userid=0;
$useridsql = "SELECT id FROM users WHERE username = '$username'";
$query_id = mysqli_query($connection, $useridsql);
$result = mysqli_num_rows($query_id);

//$query_id = $connection -> mysqli_query($useridsql);
if ($result == 1){
//if($query_id -> num_rows > 0){
  while($row = mysqli_fetch_assoc($query_id)){
    $userid = $row['id'];
  }
}

echo $userid;
$sql_id = "SELECT MAX(post_id) FROM forum";
//$query_id = $connection -> query($sql_id);
$query_id = mysqli_query($connection, $sql_id);
$row = mysqli_fetch_assoc($query_id);
//$row = $query_id -> fetch_assoc();
$post_id = $row["MAX(post_id)"] + 1;
$change_id = "ALTER TABLE forum AUTO_INCREMENT=".$post_id;
mysqli_query($connection, $change_id);
//$connection->query($change_id);

// you need to change this query into your style by inserting the values we discovered in the previous query
$sql = "INSERT INTO forum (post_id, post_username, post_name, testid, subject, message, date) VALUES ($post_id, $post_username, $post_name, $userid, CURRENT_TIMESTAMP, $subject, $message)";
//$sql = $connection -> query($sql);
mysqli_query($connection, $sql);

}

header("location: comm.php");
exit();


?>
