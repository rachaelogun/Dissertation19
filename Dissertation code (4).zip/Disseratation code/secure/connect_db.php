<?php
// Create connection
$connection = mysqli_connect("localhost", "root", "", "login_systemy")
OR die (mysqli_connect_error());
mysqli_set_charset($connection, 'utf-8');

?>
