<?php
// core configuration
include('productsession.php');
	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM products WHERE id=$id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$name = $n['name'];
			$description = $n['description'];
      $price = $n['price'];

		}

	}

?>

<!DOCTYPE html>
<html>
<head>
	<title> Update Profile</title>
  <link rel="stylesheet" type="text/css" href="product.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

</head>
<body>
	<?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>

<?php $results = mysqli_query($db, "SELECT * FROM products"); ?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Create a Products</title>

    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

</head>
<body>

    <!-- container -->
    <div class="container">

        <div class="page-header">
            <h1>Create Product</h1>
        </div>

        <form action="productsession.php" method="post">
            <table class='table table-hover table-responsive table-bordered'>


              <input type="hidden" name="id" value="<?php echo $id; ?>">

                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name" class="form-control" value="<?php echo $name; ?>"></td>
                </tr>
                <tr>
                    <td>Description</td>
                    <td><textarea type="text" name="description" class="form-control" value="<?php echo $description; ?>"></textarea></td>
                </tr>
                <tr>
                    <td>Price</td>
                    <td><input type="text" name="price" class="form-control" value="<?php echo $price; ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td>

                        <a href='products.php' class='btn btn-danger'>Back to read products</a>
                        <?php if ($update == true): ?>
                    			<button class="btn" type="submit" name="update"  style="background: #556B2F;" >update</button>
                    		<?php else: ?>
                    			<button class='btn btn-primary' type="submit" name="save" value='Save'>Save</button>
                    		<?php endif ?>
                    </td>
                </tr>
            </table>
        </form>

    </div> <!-- end .container -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>
