<?php
$page_title ='PHP Post Message';
//entry.php
include_once "authenticate.php";

// set page title
$page_title="Customer";
// include page header HTML
include_once 'header.php';
echo "<div class='col-md-12'>";
          echo "<div class='alert alert'>";
            echo "<strong>Hi " . $_SESSION['username'] . ", welcome back!</strong>";
        echo "</div>";
echo "</div>";
//session_start();
$connection = mysqli_connect("localhost", "root", "", "login_systemy");

echo "<form action='forumprocess.php' method='POST' accept-charset='utf-8'>
First Name : <input name='post_name' type='text'>
Last Name : <input name= 'post_username' type='text'>
<p>Subject :<br>
<input name='subject' type='text' size='64'></p>
<p>Message :<br>
<textarea name='message' rows='5' cols='50'>
</textarea></p>
<p><input type='submit' value='Submit'></p>
</form>";
echo "<p>
<a href='forum.php'>Forum</a></p>";
