<?php

include "conn.php";

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			array_push($_SESSION['shopping_cart'], $item_array);
		}
		else
		{
			echo '<script>alert("Item Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="homepage.php"</script>';
			}
		}
	}
}


// core configuration
include('productsession.php');
	if (isset($_GET['view'])) {
		$id = $_GET['view'];
		$record = mysqli_query($db, "SELECT * FROM products WHERE id=$id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$image = $n['image'];
			$name = $n['name'];
			$description = $n['description'];
      $price = $n['price'];
		}
	}

?>

<!-- navbar -->
<link rel="stylesheet" type="text/css" href="nav.css">
<div class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container-fluid">

        <div class="navbar-header">
            <!-- to enable navigation dropdown when viewed in mobile device -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <?php echo'<img src="l.png" alt="logoPlaceholder" height="95" width="300">'?>
      </div>

      <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">

              <!-- pages in the navigation bar of the webpage -->
              <li >
                  <a href="homepage.php">Home</a>
              </li>

							<li>
								<a href="forum.php" >Forum
									<span class="glyphicon glyphicon-comment" role="button" aria-expanded="false"></span>
								</a>
							</li>

							<li>
									<a href="items.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
										<i class="fa fa-caret-down"></i>
											Products <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
											</a>
											<ul class="dropdown-menu" role="menu">
												<li><a href="items.php">Products</a></li>
											</ul>
										</a>
									</li>








              <?php
              function my_shopping_cart_total_product_count() {
                  $product_count = 0;

                  if ( isset( $_SESSION['shopping_cart'] ) ) {
                      $product_count = array_sum( array_column( $_SESSION['shopping_cart'], 'item_quantity' ) );
                  }

                  return $product_count;
              }
              ?>
                <li>
                  <a href="cart.php" >Cart
                    <span class="glyphicon glyphicon-shopping-cart" role="button" aria-expanded="false"></span>
                      &nbsp;&nbsp;<?php echo my_shopping_cart_total_product_count(); ?>
                  </a>
                </li>

          <!-- options in the upper right corner of the page -->
              <li>
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                      <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                      &nbsp;&nbsp;<?php echo $_SESSION['username']; ?>
                      &nbsp;&nbsp;<span class="caret"></span>
                  </a>
                  <ul class="dropdown-menu" role="menu">
                      <!-- log out user -->
                      <li><a href="logout.php?token=<?= $_SESSION['user_token'] ?>">Logout</a></li>
											<li><a href="profile.php">Edit Profile</a></li>
                  </ul>
              </li>
          </ul>

      </div><!--/.nav-collapse -->

  </div>
</div>
<!-- /navbar -->
