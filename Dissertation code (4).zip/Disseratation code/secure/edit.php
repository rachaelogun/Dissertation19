<?php
// core configuration
include('productsession.php');
	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM products WHERE id=$id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$name = $n['name'];
			$description = $n['description'];
			$price = $n['price'];
		}
	}
?>

<!DOCTYPE HTML>
	<html>
	<head>
	    <title>PDO - Update a Record - PHP CRUD Tutorial</title>

	    <!-- Latest compiled and minified Bootstrap CSS -->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

	</head>
	<body>

	    <!-- container -->
	    <div class="container">

	        <div class="page-header">
	            <h1>Update Product</h1>
	        </div>
					<?php if (isset($_SESSION['message'])): ?>
						<div class="msg">
							<?php
								echo $_SESSION['message'];
								unset($_SESSION['message']);
							?>
						</div>
					<?php endif ?>

				<?php $results = mysqli_query($db, "SELECT * FROM products"); ?>



					<?php while ($row = mysqli_fetch_array($results)) { ?>

					<?php } ?>


	<form method="post" action="productsession.php" >

		<input type="hidden" name="id" value="<?php echo $id; ?>">

		<div class="input-group">
			<label>Name</label>
			<input type="text" name="name" value="<?php echo $name; ?>">
		</div>
		<div class="input-group">
			<label>description</label>
			<input type="text" name="description" value="<?php echo $description; ?>">
		</div>
		<div class="input-group">

			<?php if ($update == true): ?>
				<button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
			<?php else: ?>
				<button class="btn" type="submit" name="save" >Save</button>
			<?php endif ?>
		</div>
	</form>
	    </div> <!-- end .container -->

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

	<!-- Latest compiled and minified Bootstrap JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	</body>
	</html>
