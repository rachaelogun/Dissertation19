<!-- navbar -->
<div class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container-fluid">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <?php echo'<img src="l.png" alt="logoPlaceholder" height="95" width="300">'?>
        </div>


        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <div class= "tap"><a href="register.php"</a></div></span>  </li>
              <li <?php echo $page_title=="Register" ? "class='active'" : ""; ?>>
                <span class="glyphicon glyphicon-check"></span> <href <?php echo 'register.php> Register' ?>
                </a>
              </li>

                <ul class="nav navbar-nav navbar-right-right">
              <div class= "tap"><a href="login.php"</a></div></span>  </li>
                <li <?php echo $page_title=="Login" ? "class='active'" : ""; ?>>
                  <span class="glyphicon glyphicon-log-in"></span> <href <?php echo 'login.php> Login' ?>
                  </a>
                </li>
            </ul>

          </ul>
      </div>

    </div>
</div>
