<?php
	$db = mysqli_connect('localhost', 'root', '', 'login');

	// initialize variables
	$name = "";
	$description = "";
	$price = "";
	$id = 0;
	$update = false;

	if (isset($_POST['save'])) {
		$name = $_POST['name'];
		$description = $_POST['description'];
		$price = $_POST['price'];

		mysqli_query($db, "INSERT INTO products (name, description, price) VALUES ('$name', '$description', '$price')");
		$_SESSION['message'] = "Product saved!";
		header('location: create.php');
	}

	if (isset($_POST['update'])) {
		$id = $_POST['id'];
		$name = $_POST['name'];
		$description = $_POST['description'];
		$price = $_POST['price'];

		mysqli_query($db, "UPDATE products SET name='$name', description='$description', price='$price' WHERE id=$id");
		$_SESSION['message'] = "Product updated!";
		header('location: products.php');
	}

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM products WHERE id=$id");
	$_SESSION['message'] = "Product deleted!";
	header('location: products.php');
}

	$results = mysqli_query($db, "SELECT * FROM products");
?>
