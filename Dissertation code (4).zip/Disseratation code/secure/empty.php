
<?php
	if(!empty($_SESSION["shopping_cart"])) {
		foreach($_SESSION["shopping_cart"] as $k => $v) {
			if($_GET["id"] == $k)
				unset($_SESSION["shopping_cart"][$k]);
			if(empty($_SESSION["shopping_cart"]))
				unset($_SESSION["shopping_cart"]);
		}
	}
	break;
	unset($_SESSION["shopping_cart"]);
        break;
