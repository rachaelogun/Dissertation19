<?php
// core configuration
include ('db.php');

session_start();
if ($connection = mysqli_connect(dbhost, dbuser, dbpass)){
	//the connection information holding the hostname, username and password of the database been accessed

	//Handles the errors that occurs
		if(!mysqli_select_db($connection, dbname)){
			//check that the database can be accessed
			die("Database couldn't be used. Try again!!".mysqli_connect_error($connection));
			//if not connection dies and user needs try again.
			exit();
		}
		else
		{
			if(!$connection->set_charset("utf-8")){
				//if the connection isnt correct
				$result = "error loading utf-8";
				//error message displayed
			}
			else
			{
				//else utf8 will be set
				$result = " utf-8 set";
			}
		}
	}
	else
	{
		//connection error to MySQL
		die("Unable to connect to MySQL, Try again!!".mysqli_connect_error($connection));
		exit();
	}

// set page title
$page_title="Customer";
// include page header HTML
include_once 'header.php';
echo "<div class='col-md-12'>";
          echo "<div class='alert alert'>";
            echo "<strong>Hi " . $_SESSION['username'] . ", welcome back!</strong>";
        echo "</div>";
echo "</div>";

$_SESSION['LAST_ACTIVITY'] = time();
if(isset($_SESSION['loggedIn'])){
    $username = $_SESSION['username'];
}
if (isset($_GET['view'])) {
  $id = $_GET['view'];
  $record = mysqli_query($connection, "SELECT * FROM users WHERE id=$id");

  if (@count($record) == 1 ) {
    $n = @mysqli_fetch_array($record);
    $username = $n['username'];

  }
}
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$update = true;
	$record = @mysqli_query($connection, "SELECT * FROM users WHERE id=$id");

	if (@count($record) == 1 ) {
				$n = @mysqli_fetch_array($record);
				$name = $n['name'];
				$lname = $n['lname'];
				$address = $n['address'];
				$country = $n['country'];
				$number = $n['number'];
						}

}
// set page title
$page_title="Update Profile";
// include page header HTML
//include_once 'header.php';

?>
<!DOCTYPE html>
<html>
<head>
<title> Update Profile</title>
<link rel="stylesheet" type="text/css" href="../css/profile.css">
</head>
<body>
<?php if (isset($_SESSION['message'])): ?>
	<div class="msg">
		<?php
			echo $_SESSION['message'];
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>

<?php $results = @mysqli_query($connection, "SELECT * FROM users"); ?>
<?php while ($row = mysqli_fetch_array($results)) { ?>

<?php } ?>

<html>
<body>
<div class="container">
 <div class="row">
	 <div class="col-sm-12">
		 <div class="jumbotron">
			 <link rel="stylesheet" type="text/css" href="check.css">
			 <div class="d-flex">
				 <form method="post" action="profilesession.php" >
					<input type="hidden" name="id" value="<?php echo $id; ?>">

					<div class="input-group">
						<label>Name</label>
						<input type="text" name="name" value="<?php echo $name; ?>">
					</div>
						<div class="input-group">
							<label>Last Name</label>
							<input type="text" name="lname" value="<?php echo $lname; ?>">
						</div>
					<div class="input-group">
						<label>Address</label>
						<input type="text" name="address" value="<?php echo $address; ?>">
					</div>
					<div class="input-group">
						<label>Country</label>
						<input type="text" name="country" value="<?php echo $country; ?>">
					</div>
					<div class="input-group">
						<label>Phone Number</label>
						<input type="text" name="number" value="<?php echo $number; ?>">
					</div>
					<div class="input-group">

						<?php if ($update == true): ?>
							<button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
						<?php else: ?>
							<button class="btn" type="submit" name="save" >Save</button>
						<?php endif ?>
					</div>
				</form>
				</body>
				</html>
