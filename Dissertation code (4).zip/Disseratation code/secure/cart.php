<?php
session_start();
//include_once "config.php";
// set page title
$page_title="Cart";
// include page header HTML
include_once 'header.php';

//include "db.php";
// set page title
//include_once "authenticate.php";
if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'image'			=>	$_POST["image"],
				'description'			=>	$_POST["description"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			array_push($_SESSION['shopping_cart'], $item_array);
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'image'			=>	$_POST["image"],
			'description'			=>	$_POST["description"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>window.location="cart.php"</script>';
			}
		}
	}
}
    ?>


<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-10 col-md-offset-1">
            <table class="table">
                <thead>
                    <tr>
                        <th><h3>Product</h3></th>
                        <th><h3>Quantity</h3></th>
                        <th><h3>Price</h3></th>
                        <th><h3>Total</h3></th>
                        <th> </th>
                    </tr>
                </thead>
								<?php
    if(!empty($_SESSION["shopping_cart"]))
    {
      $total = 0;
      foreach($_SESSION["shopping_cart"] as $keys => $values)
      {
    ?>



  <tbody>
		<tr>
				<td class="col-sm-6 col-md-8">
				<div class="media">
						<div class="media-body">
								<h4 class="media-heading"><a href=""><?php echo $values["item_name"]; ?></a></h4>
								<span>Status: </span><span class="text-success"><strong>In Stock</strong></span>
						</div>
				</div></td>
				<td class="col-sm-1 col-md-1" style="text-align: center">
				<input onkeydown="return false"  value= <?php echo $values["item_quantity"]; ?>>
				</td>
				<td class="col-sm-1 col-md-1 text-center"><strong>£<?php echo $values["item_price"]; ?></strong></td>

				<td class="col-sm-1 col-md-1 text-center"><strong>£<?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?></strong></td>
				<td class="col-sm-1 col-md-1">
					<a href="homepage.php?action=delete&id=<?php echo $values["item_id"]; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span> Remove</a></td>
				</tr>

				<?php
$total = $total + ($values["item_quantity"] * $values["item_price"]);
}
?>
		<tr>
				<td>   </td>
				<td>   </td>
				<td>   </td>
				<td><h5>Subtotal</h5></td>
				<td class="text-right"><h5><strong>£<?php echo number_format($total, 2); ?></strong></h5></td>
		</tr>

			<?php	 $num = 25;
		 $percentage = 20;
		 $num += $num*($percentage/100);
		 $num = round($num, 1);      // 4
		 $num = sprintf('%0.2f', $num);
				?>
		<tr>
				<td>   </td>
				<td>   </td>
				<td>   </td>
				<td><h5>Estimated shipping</h5></td>
				<td class="text-right"><h5><strong>£<?php echo $num;?></strong></h5></td>
		</tr>

		<?php
$final = $total + $num;
?>
		<tr>
				<td>   </td>
				<td>   </td>
				<td>   </td>
				<td><h3>Total</h3></td>
				<td class="text-right"><h3><strong>£<?php echo $final; ?></strong></h3></td>
		</tr>
		<tr>
				<td>   </td>
				<td>   </td>
				<td>   </td>
				<td>
					<td><a href="homepage.php" class="btn btn-primary"><span class="glyphicon glyphicon-shopping-cart"></span> Continue shopping</a></td>

				<td>
					<td><a href="testcheck.php" class="btn btn-success"><span class="glyphicon glyphicon-shopping-cart"></span> Checkout</a></td>
					<?php
					}
					?>
					<td>  <a href="homepage.php?action=clear&id=<?php echo $values["item_id"]; ?>" class="btn btn-danger" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Empty Cart</a>
				</td>
		</tr>

</tbody>
</table>
</div>
</div>
</div>
