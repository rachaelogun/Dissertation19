<?php
  // This sets or defines the connection information from the database to connect, this is a constant value set for more protection

  DEFINE ('dbhost', 'localhost'); //sets all the information for logging into the database to be checked, ensure that the privileges set aren't too much to avoid vulnerablities within the connection set.
  DEFINE ('dbuser', 'root');
  DEFINE ('dbpass', ''); // password needs to be set within the databse to ensure that the database isnt open and susceptible to attackers geeting access into the database.
  DEFINE ('dbname', 'login_systemy');
?>
