<?php
$page_title="Login";
// include page header HTML
include_once 'sessionheader.php';
// footer HTML and JavaScript codes
?>

  <?php header("Content-Type: text/html; charset=utf-8"); ?>
  <!DOCTYPE html>
  <html>
  <head>
    <meta http-equiv="content-type" content = "text/html" charset="utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <link rel = "stylesheet" href = "expired.css">

  </head>
  <body>
    <div class = "contain">
      <div class = "holder">
        <div class = "title">
          <h1><?php echo'<img src="danger.png" alt="logoPlaceholder" height="50" width="80">'?>Your Session has Expired</h1>
        </div>
        <div class = "text">
          <p><h3>For security reasons and in order to protect your privacy, the session has expired.
            If you would like to continue, please click the button below to login.</p></h3>
        </div>
      </div>
      <div class = "re-log">
        <a href="login.php" class="btn btn-danger">Re-Login</a>
      </div>
    </div>

  </body>
  </html>
