<?php

  $timeout = 60*1;

  if(isset($_SESSION['LAST_ACTIVITY'])){
    $duration = time() - (int)$_SESSION['LAST_ACTIVITY'];
    if($duration > $timeout){
      session_destroy();
      header("location:expired_session.php");
      exit();
    } else {

    }
  }

  $_SESSION['LAST_ACTIVITY'] = time();
?>
