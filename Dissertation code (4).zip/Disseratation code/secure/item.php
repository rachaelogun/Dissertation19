<?php
// core configuration
session_start();

include "db.php";
// set page title
//include_once "authenticate.php";

$page_title="Customer";
// include page header HTML
include_once 'itemhead.php';
//session_start();
$connect = mysqli_connect("localhost", "root", "", "login_systemy");

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'image'			=>	$_POST["image"],
				'description'			=>	$_POST["description"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			array_push($_SESSION['shopping_cart'], $item_array);
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'image'			=>	$_POST["image"],
			'description'			=>	$_POST["description"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>window.location="homepage.php"</script>';
			}
		}
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "clear")
	{
    foreach($_SESSION["shopping_cart"] as $keys => $values)
    		{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>window.location="homepage.php"</script>';
			}
		}
	}
// core configuration
//include('productsession.php');
	if (isset($_GET['view'])) {
		$id = $_GET['view'];
		$record = mysqli_query($db, "SELECT * FROM products WHERE id=$id");

		if (@count($record) == 1 ) {
			$n = @mysqli_fetch_array($record);
			$image = $n['image'];
			$name = $n['name'];
			$description = $n['description'];
      $price = $n['price'];
		}
	}

?>

<!DOCTYPE HTML>
<html>
<head>

    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
		<link rel="stylesheet" href="view.css" />

</head>
<body>

        <?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>
<?php $results = mysqli_query($db, "SELECT * FROM products"); ?>
	<?php while ($row = mysqli_fetch_array($results)) { ?>
	<?php } ?>

<br><br><br>

<?php
	$username=$_SESSION["username"];//session id of the current user
	$query= mysqli_query($connection, "SELECT * FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id
 ?>


	<?php while (	$row = @mysqli_fetch_array($query));
{ ?>
	<?php

  //include_once('connection.php'); //For connecting the database

    $username=$_SESSION["username"];//session id of the current user
    $query= mysqli_query($connection, "SELECT * FROM users WHERE username = '$username' "); //sql to extract name of the user associated with the current session id

    // to display the row of the database as string not as resource id, we must use functions such as mysql_fetch_assoc() or mysql_fetch_row(). They have return type of array
    $row = @mysqli_fetch_array($query);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Home</title>
  <link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="item.css">

</head>

<body>
	<h3> Product</h3>
	<form method="post" action="forumprocess.php">
				<td>
				</td>
				<main class="container">
			  <div class="right-column">
					<td rowspan="7"><img src="<?php echo $image; ?>" width= "80%" /></td>
			  </div>

			    <!-- Product Description -->
			    <div class="product-description">
			      <h2><?php echo $name; ?></h2>
						<h4><?php echo $description; ?></h4>
	          <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />
	          <input type="hidden" name="hidden_price" value="<?php echo $row["description"]; ?>" />


			    </div>

			    <!-- Product Pricing -->
			    <div class="product-price">
			      <span>£<?php echo $price; ?></span>

</div>
</div>
</main>
<br><br><br>

<?php
$connection = mysqli_connect("localhost", "root", "", "login_systemy");
$username = $username;

echo "<div class= 'hold'>";
echo "<form action='forumprocess.php' method='POST'>
<p>Message :<br>
<textarea name='message' rows='5' cols='50'>
</textarea></p>
<p><input type='submit' value='Submit'></p>
</form>";
echo "<p>";
echo "</div>";
"<a href='forum.php'>Forum</a></p>";
?>
<br><br><br>
<?php } ?>

				<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
				<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

				<!-- Latest compiled and minified Bootstrap JavaScript -->
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

				</body>

				</html>
