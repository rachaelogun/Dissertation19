<?php
// set page title
$page_title = "Register";
include_once "registration.php";
// include page header HTML
include_once "loginhead.php";

echo "<div class='col-md-12'>";

    // registration form HTML will be here
    // code when form was submitted will be here
   ?>

   <form method='post'>
     <div class="alert alert-danger text-center" style= "center" role="alert">
          <?php if (isset($usernamerror) ): ?>
          <?php echo $usernamerror; ?>
        <?php endif ?>
        <?php if (isset($passworderror) ): ?>
        <?php echo $passworderror; ?>
      <?php endif ?>
      <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>

       <table class='table table-responsive'>

           <tr>
               <td class='width-30-percent'>Username</td>
               <td><input type='text' name='username' class='form-control' required></td>
           </tr>
           <tr>
               <td class='width-30-percent'>Name</td>
               <td><input type='text' name='name' class='form-control' required></td>
           </tr>
           <tr>
               <td class='width-30-percent'>Last Name</td>
               <td><input type='text' name='lname' class='form-control' required></td>
           </tr>
           <tr>
             <td class='width-30-percent'>Address</td>
               <td><textarea name='address' class='form-control' required></textarea></td>
           </tr>
           <tr>
             <td class='width-30-percent'>Country</td>
               <td><input type='text' name='country' class='form-control' required></td>
           </tr>
           <tr>
             <td class='width-30-percent'>Phone Number</td>
               <td><input type='text' name='number' class='form-control' required></td>
           </tr>
           <tr>
             <td class='width-30-percent'>Password</td>
               <td><input type='password' name='password' class='form-control' required></td>
           </tr>
           <td></td>
           <td><div class='g-recaptcha' data-sitekey='6LcwhZ0UAAAAAD7M-PmOUrASP-J_bV4DjE-ZSMh7'></div>

                    <input type="submit" name="register" value="Register" class="btn btn-info" />
                    <br />
                    <input type = 'hidden' name = 'recaptcha' value = 'TRUE'>

                  </td>
              </tr>
                  </table>

               </form>
          </div>
     </body>
</html>
<?php
echo "</div>";


// include page footer HTML
include_once "footer.php";
?>
