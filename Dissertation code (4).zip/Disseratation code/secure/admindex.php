<?php
// core configuration
session_start();
require_once "connect.php";
include "sessionchecker.php";
//include "checkid.php";

//include "authenticate.php";

// set page title
$page_title="Admin";
// include page header HTML
include 'adminhead.php';
echo "<div class='col-md-12'>";
          echo "<div class='alert alert-success'>";
            echo "<strong>Hi " . $_SESSION['username'] . ", welcome back!</strong>";
        echo "</div>";
echo "</div>";

  ?>

<!DOCTYPE html>
<html>
	<head>
		<title>ADMIN</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="index.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</head>
	<body>

      	</body>
      </html>
