Read me:


The files will be accessible on mi-linux.wlv.ac.uk when enough space is available.

1. Download Apache server (XAMPP) https://www.apachefriends.org/index.html
2. Run as an admin on system. 
3. copy all 3 folders into htdocs within the XAMPP folders in window C
4. Export both sql file into phpmyadmin.
5. Log in to each site

SiteX (users) - username: peter00 password: peter

SiteX (admin)- username: admin password: admin

SiteY (users) - username: peter00 password: peter

SiteY (admin)- username: admin password: admin123
